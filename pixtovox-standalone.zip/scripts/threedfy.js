let roughnessValue=0.1;
let metalnessValue=0.91;
let ambLightIntensity=7;
let dirLightIntensity=4;
let subdivisions=18;
let roundingFactor=0.2;
let cellSpacingFactor=0.85;
let thicknessFactor=1.0;
let geometryIndex=1;
const roughnessControl = document.getElementById("roughnessControl");
const roughnessDisplay = document.getElementById("roughnessDisplay");

const metalnessControl = document.getElementById("metalnessControl");
const metalnessDisplay = document.getElementById("metalnessDisplay");

const ambLightControl = document.getElementById("ambLightControl");
const ambLightDisplay = document.getElementById("ambLightDisplay");

const dirLightControl = document.getElementById("dirLightControl");
const dirLightDisplay = document.getElementById("dirLightDisplay");

// Actualizar valores y mostrar cambios

ambLightControl.addEventListener("input", function() {
ambLightDisplay.textContent = this.value;
updateLights();
updateMaterial();
});


dirLightControl.addEventListener("input", function() {
dirLightDisplay.textContent = this.value;
updateLights();
updateMaterial();

});

roughnessControl.addEventListener("input", function() {
roughnessDisplay.textContent = this.value;
updateLights();
updateMaterial();
});


metalnessControl.addEventListener("input", function() {
metalnessDisplay.textContent = this.value;
updateLights();
updateMaterial();
});


function updateLights() {

ambientLight.intensity = parseFloat(ambLightControl.value);
cameraLight.intensity = parseFloat(dirLightControl.value);
}

const pointLight = new THREE.PointLight(0xffffff, 10, 5000); // Color, Intensidad, Distancia
pointLight.position.set(500, 500, -500);
pointLight.castShadow = true;

const hemisphereLight = new THREE.HemisphereLight(0xffffff, 0x444444, 11); // Color del cielo, Color del suelo, Intensidad
hemisphereLight.position.set(50, 50, -50);



function updateMaterial() {


roughnessValue = parseFloat(roughnessControl.value);
metalnessValue = parseFloat(metalnessControl.value);

if (sprites3d[currentSpriteIndex]) {
sprites3d.forEach(mesh => {
if (mesh.material) {
mesh.material.roughness = roughnessValue;
mesh.material.metalness = metalnessValue;
mesh.material.needsUpdate = true;
}
});
}
}

document.getElementById("thicknessControl").addEventListener("input", function(e) {
thicknessFactor = parseFloat(e.target.value);

document.getElementById("thicknessDisplay").textContent = thicknessFactor;
});


document.getElementById("subdivisionsControl").addEventListener("input", function(e) {
subdivisions = parseInt(e.target.value, 10);
document.getElementById("subdivisionsDisplay").textContent = subdivisions;
});

document.getElementById("roundingControl").addEventListener("input", function(e) {
roundingFactor = parseFloat(e.target.value);

document.getElementById("roundingDisplay").textContent = roundingFactor;
});

document.getElementById("spacingControl").addEventListener("input", function(e) {
cellSpacingFactor = parseFloat(e.target.value);
document.getElementById("spacingDisplay").textContent = cellSpacingFactor;
});

/*
function updateGeometry(){

if (isPlaying)
{
togglePlayPause();
}

menu3DShape.style.display="none";
stopThreeD();
startThreeD();

}
*/

function updateGeometry(){

geometryIndex = (geometryIndex<5) ? geometryIndex+1 : 1;

switch(geometryIndex)
{
case 1 : 

subdivisions = 18;
roundingFactor = 0.2;
cellSpacingFactor = 0.85;
break;

case 2 : 

subdivisions = 1;
roundingFactor = 0;
cellSpacingFactor = 1.0;


break;

case 3: 

subdivisions = 5;
roundingFactor = 0.2;
cellSpacingFactor = 0.85;


break;

case 4 : 

subdivisions = 12;
roundingFactor = 0.1;
cellSpacingFactor = 0.9;

break;

case 5 : 

subdivisions = 16;
roundingFactor = 0.3;
cellSpacingFactor = 0.76;

break;

}


if (isPlaying)
{
togglePlayPause();
}

menu3DShape.style.display="none";
stopThreeD();
startThreeD();

}


function resetGeometry() {

if (isPlaying)
{
togglePlayPause();
}
// Restablece los valores del menú de Geometría
document.getElementById("subdivisionsControl").value = 6;
document.getElementById("subdivisionsDisplay").textContent = "6";

document.getElementById("roundingControl").value = 0.1;
document.getElementById("roundingDisplay").textContent = "0.1";

document.getElementById("spacingControl").value = 1;
document.getElementById("spacingDisplay").textContent = "0.9";

document.getElementById("thicknessControl").value = 1;
document.getElementById("thicknessDisplay").textContent = "1";



subdivisions=18;
roundingFactor=0.2;
cellSpacingFactor=0.85;
thicknessFactor=1.0;

if(sprites3d.length>0)
{
updateGeometry();
}

}


function resetLights() {
// Restablece los valores del menú de Luces
document.getElementById("roughnessControl").value = 0.1;
document.getElementById("roughnessDisplay").textContent = "0.1";

document.getElementById("metalnessControl").value = 0.91;
document.getElementById("metalnessDisplay").textContent = "0.91";

document.getElementById("ambLightControl").value = 7;
document.getElementById("ambLightDisplay").textContent = "7";

document.getElementById("dirLightControl").value = 4;
document.getElementById("dirLightDisplay").textContent = "4";

updateLights();
updateMaterial();
}

function close3DMenu(menuID)
{
menuID.style.display="none";
}

let renderer, scene, camera;
let isThreeDActive = false;
//let sprites3d = []; // Array para almacenar los sprites 3D

let fpsDisplay = document.getElementById('outputFPS'); // Elemento para mostrar FPS



let lastFrameTime = performance.now(); // Tiempo del último cuadro renderizado
let frameCount = 0; // Contador de cuadros
let fps = 0; // Variable para almacenar FPS

let lastSpriteIndex = currentSpriteIndex;


// =====================//
//= Función RGB TO OBJECT=
// =====================//
function rgbStringToObject(colorString) {
// Si es hexadecimal, convierte a objeto RGB
if (colorString.startsWith('#')) {
let hex = colorString.slice(1);
// Si es notación corta (#f00), la expandimos (#ff0000)
if (hex.length === 3) {
hex = hex.split('').map(ch => ch + ch).join('');
}
const r = parseInt(hex.substr(0, 2), 16);
const g = parseInt(hex.substr(2, 2), 16);
const b = parseInt(hex.substr(4, 2), 16);
return { r, g, b };
}
// Si es formato rgb(...) o rgba(...)
else if (colorString.startsWith('rgb')) {
const matches = colorString.match(/\d+/g);
if (matches && matches.length >= 3) {
const [r, g, b] = matches.map(Number);
return { r, g, b };
}
}
// Valor por defecto
return { r: 0, g: 0, b: 0 };
}

const ambientLight = new THREE.AmbientLight(0xffffff, ambLightIntensity); // Luz ambiental suave

// Agregar una luz direccional a la cámara con mayor intensidad para iluminar la escena
const cameraLight = new THREE.DirectionalLight(0xffffff, dirLightIntensity); // Intensidad aumentada

cameraLight.position.set(0, 0, -10);
cameraLight.target.position.set(2, 0, 0);


/*
cameraLight.castShadow = false; // Habilitar sombras
cameraLight.shadow.mapSize.width = 2048; // Resolución de la sombra
cameraLight.shadow.mapSize.height = 2048;
cameraLight.shadow.bias = 0.001; // Ajuste de bias para suavizar sombras
*/
function getFovBasedOnOrientation() {
// Si el ancho es mayor que el alto, asumimos orientación horizontal
return window.innerWidth > window.innerHeight ? 30 : 90;
}
// =====================//
//= Función init() =
// =====================//
function init() {
renderer = new THREE.WebGLRenderer({
canvas: canvasThree,
antialias: true,
alpha: true
});
renderer.setSize(window.innerWidth, window.innerHeight);


renderer.shadowMap.enabled = false;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;

//cameraLight.shadow.radius =1; // Puedes probar distintos valores

// Establecer el color de fondo a negro pero totalmente transparente
renderer.setClearColor(0x000000, 0);

scene = new THREE.Scene();


camera = new THREE.PerspectiveCamera(
getFovBasedOnOrientation(),
window.innerWidth / window.innerHeight,
0.1,
100000
);

camera.position.z = -50;

// Agregar la cámara a la escena para que la luz hija se renderice
scene.add(camera);
scene.add(cameraLight.target);
// Agregar una luz ambiental para suavizar la iluminación

 scene.add(ambientLight);

 //scene.add(cameraLight);
 scene.add(pointLight);
}


// Asegúrate de inicializar isDragging y previousMouseX
//let isDragging = false;
//let previousMouseX = 0;


// Raycaster y vector del mouse
const raycaster = new THREE.Raycaster();
const mouse = new THREE.Vector2();

function createTriangle(vertices, face, cellIndex, color, uvs = null) {
let tri = [...vertices];
tri.face = face;
tri.cellID = cellIndex;
tri.visible = true;
tri.baseColor = { ...color };
if (uvs) {
// Guardamos las coordenadas UV para cada vértice del triángulo
tri.uvs = uvs;
}
return tri;
}

/*
function createRoundedCubeTriangles(x, y, z, scale, rounding, cellIndex, layerIndex, color, hiddenFaces, textured) {
let triangles = [];

let cx = x + scale / 2;
let cy = y - scale / 2;
let cz = z + scale / 2;

let faces = [
{ name: "top", origin: { x: x, y: y, z: z }, uDir: { x: scale, y: 0, z: 0 }, vDir: { x: 0, y: 0, z: scale } },
{ name: "bottom", origin: { x: x, y: y - scale, z: z }, uDir: { x: scale, y: 0, z: 0 }, vDir: { x: 0, y: 0, z: scale } },
{ name: "front", origin: { x: x, y: y, z: z }, uDir: { x: scale, y: 0, z: 0 }, vDir: { x: 0, y: -scale, z: 0 } },
{ name: "back", origin: { x: x, y: y, z: z + scale }, uDir: { x: scale, y: 0, z: 0 }, vDir: { x: 0, y: -scale, z: 0 } },
{ name: "right", origin: { x: x, y: y, z: z }, uDir: { x: 0, y: 0, z: scale }, vDir: { x: 0, y: -scale, z: 0 } },
{ name: "left", origin: { x: x + scale, y: y, z: z }, uDir: { x: 0, y: 0, z: scale }, vDir: { x: 0, y: -scale, z: 0 } }
];

faces.forEach(face => {
if (hiddenFaces && hiddenFaces[face.name]) {
return;
}

// Para acumular vertices y, si es texturizado, UVs
let verticesGrid = [];
let uvsGrid = [];

for (let i = 0; i <= subdivisions; i++) {
verticesGrid[i] = [];
if (textured) {
uvsGrid[i] = [];
}
for (let j = 0; j <= subdivisions; j++) {
let u = j / subdivisions;
let v = i / subdivisions;

// Posición original sin redondear
let pos = {
x: face.origin.x + face.uDir.x * u + face.vDir.x * v,
y: face.origin.y + face.uDir.y * u + face.vDir.y * v,
z: face.origin.z + face.uDir.z * u + face.vDir.z * v,
};

// Convertir a coordenadas locales respecto al centro del cubo
let local = { x: pos.x - cx, y: pos.y - cy, z: pos.z - cz };
let half = scale / 2;

// "Clamp" para la zona interna sin redondeo
let clamped = {
x: Math.max(-half + rounding, Math.min(half - rounding, local.x)),
y: Math.max(-half + rounding, Math.min(half - rounding, local.y)),
z: Math.max(-half + rounding, Math.min(half - rounding, local.z))
};

// Calcular offset para la región a redondear
let offset = {
x: local.x - clamped.x,
y: local.y - clamped.y,
z: local.z - clamped.z
};

let len = Math.sqrt(offset.x * offset.x + offset.y * offset.y + offset.z * offset.z);
if (len > 0) {
let factor = rounding / len;
offset.x *= factor;
offset.y *= factor;
offset.z *= factor;
local.x = clamped.x + offset.x;
local.y = clamped.y + offset.y;
local.z = clamped.z + offset.z;
}

// Regresar a coordenadas globales
pos.x = cx + local.x;
pos.y = cy + local.y;
pos.z = cz + local.z;

verticesGrid[i][j] = pos;
if (textured) {
// Asignar unas UV básicas basadas en u y v (se puede ajustar según la orientación)
uvsGrid[i][j] = { u: u, v: v };
}
}
}

// Conectar los vértices formando dos triángulos por celda en la cuadrícula
for (let i = 0; i < subdivisions; i++) {
for (let j = 0; j < subdivisions; j++) {
let v1 = verticesGrid[i][j];
let v2 = verticesGrid[i][j+1];
let v3 = verticesGrid[i+1][j];
let v4 = verticesGrid[i+1][j+1];

if (textured) {
let uv1 = uvsGrid[i][j];
let uv2 = uvsGrid[i][j+1];
let uv3 = uvsGrid[i+1][j];
let uv4 = uvsGrid[i+1][j+1];
triangles.push(createTriangle([v1, v2, v3], face.name, cellIndex, color, [uv1, uv2, uv3]));
triangles.push(createTriangle([v3, v2, v4], face.name, cellIndex, color, [uv3, uv2, uv4]));
} else {
triangles.push(createTriangle([v1, v2, v3], face.name, cellIndex, color));
triangles.push(createTriangle([v3, v2, v4], face.name, cellIndex, color));
}
}
}
});

return triangles;
}
*/

function createRoundedCubeTriangles(x, y, z, scale, rounding, cellIndex, layerIndex, color, hiddenFaces, textured) {
let triangles = [];

let cx = x + scale / 2;
let cy = y - scale / 2;
let cz = z + scale / 2;

let faces = [
{ name: "top", origin: { x: x, y: y, z: z }, uDir: { x: scale, y: 0, z: 0 }, vDir: { x: 0, y: 0, z: scale } },
{ name: "bottom", origin: { x: x, y: y - scale, z: z }, uDir: { x: scale, y: 0, z: 0 }, vDir: { x: 0, y: 0, z: scale } },
{ name: "front", origin: { x: x, y: y, z: z }, uDir: { x: scale, y: 0, z: 0 }, vDir: { x: 0, y: -scale, z: 0 } },
{ name: "back", origin: { x: x, y: y, z: z + scale }, uDir: { x: scale, y: 0, z: 0 }, vDir: { x: 0, y: -scale, z: 0 } },
{ name: "right", origin: { x: x, y: y, z: z }, uDir: { x: 0, y: 0, z: scale }, vDir: { x: 0, y: -scale, z: 0 } },
{ name: "left", origin: { x: x + scale, y: y, z: z }, uDir: { x: 0, y: 0, z: scale }, vDir: { x: 0, y: -scale, z: 0 } }
];

faces.forEach(face => {
if (hiddenFaces && hiddenFaces[face.name]) return;

let verticesGrid = [];
let uvsGrid = [];

for (let i = 0; i <= subdivisions; i++) {
verticesGrid[i] = [];
if (textured) uvsGrid[i] = [];

for (let j = 0; j <= subdivisions; j++) {
// Coordenadas UV base
let rawU = j / subdivisions;
let rawV = i / subdivisions;
let u = rawU;
let v = rawV;

// Rotar UVs según la cara para que el marcador quede en la esquina inferior derecha
if (textured) {
  switch (face.name) {
    case "top":
      u = 1 - rawU;
      v =1- rawV;
      break;
    case "bottom":
      u =1- rawU;
      v =1- rawV;
      break;
    case "front":
      u = 1 - rawU;
      v = 1 - rawV;
      break;
    case "back":
      u = 1 - rawU;
      v = 1 - rawV;
      break;
    case "left":
      u =1- rawU;
      v = 1 - rawV;
      break;
    case "right":
      u = 1 - rawU;
      v = 1 - rawV;
      break;
  }
}
// Posición 3D
let pos = {
x: face.origin.x + face.uDir.x * rawU + face.vDir.x * rawV,
y: face.origin.y + face.uDir.y * rawU + face.vDir.y * rawV,
z: face.origin.z + face.uDir.z * rawU + face.vDir.z * rawV,
};

// Coordenadas locales
let local = { x: pos.x - cx, y: pos.y - cy, z: pos.z - cz };
let half = scale / 2;

let clamped = {
x: Math.max(-half + rounding, Math.min(half - rounding, local.x)),
y: Math.max(-half + rounding, Math.min(half - rounding, local.y)),
z: Math.max(-half + rounding, Math.min(half - rounding, local.z))
};

let offset = {
x: local.x - clamped.x,
y: local.y - clamped.y,
z: local.z - clamped.z
};

let len = Math.sqrt(offset.x ** 2 + offset.y ** 2 + offset.z ** 2);
if (len > 0) {
let factor = rounding / len;
offset.x *= factor;
offset.y *= factor;
offset.z *= factor;
local.x = clamped.x + offset.x;
local.y = clamped.y + offset.y;
local.z = clamped.z + offset.z;
}

pos.x = cx + local.x;
pos.y = cy + local.y;
pos.z = cz + local.z;

verticesGrid[i][j] = pos;
if (textured) uvsGrid[i][j] = { u, v };
}
}

// Generar triángulos
for (let i = 0; i < subdivisions; i++) {
for (let j = 0; j < subdivisions; j++) {
let v1 = verticesGrid[i][j];
let v2 = verticesGrid[i][j + 1];
let v3 = verticesGrid[i + 1][j];
let v4 = verticesGrid[i + 1][j + 1];

if (textured) {
let uv1 = uvsGrid[i][j];
let uv2 = uvsGrid[i][j + 1];
let uv3 = uvsGrid[i + 1][j];
let uv4 = uvsGrid[i + 1][j + 1];
triangles.push(createTriangle([v1, v2, v3], face.name, cellIndex, color, [uv1, uv2, uv3]));
triangles.push(createTriangle([v3, v2, v4], face.name, cellIndex, color, [uv3, uv2, uv4]));
} else {
triangles.push(createTriangle([v1, v2, v3], face.name, cellIndex, color));
triangles.push(createTriangle([v3, v2, v4], face.name, cellIndex, color));
}
}
}
});

return triangles;
}

function drawCube(cell, i, j, layerIndex, gridSize, scale, cellSpacingFactor, offsetX, offsetY, layerZOffset, spriteLayers, layer, sprite, cellIndex) {
if (!cell || !cell.painted) return null;

let x = -j * scale * cellSpacingFactor + offsetX;
let y = -i * scale * cellSpacingFactor + offsetY;
let z = layerZOffset * cellSpacingFactor;

let cubeMesh = [];
let color = { ...rgbStringToObject(cell.color) };

cubeMesh.scale = scale;
cubeMesh.position = { x: x, y: y, z: z };
cubeMesh.name = `cell_${i * gridSize + j}_layer_${layerIndex}`;
cubeMesh.baseColor = { ...color };
cubeMesh.rotation = { x: 0, y: 0, z: 0 };
cubeMesh.cellID = i * gridSize + j;
cubeMesh.layerIndex = layerIndex;

let rounding = scale * roundingFactor;

let hiddenFaces = {};
hiddenFaces["top"] = (i > 0 && layer.cells[(i - 1) * gridSize + j] && layer.cells[(i - 1) * gridSize + j].painted);
hiddenFaces["bottom"] = (i < gridSize - 1 && layer.cells[(i + 1) * gridSize + j] && layer.cells[(i + 1) * gridSize + j].painted);
hiddenFaces["left"] = (j > 0 && layer.cells[i * gridSize + (j - 1)] && layer.cells[i * gridSize + (j - 1)].painted);
hiddenFaces["right"] = (j < gridSize - 1 && layer.cells[i * gridSize + (j + 1)] && layer.cells[i * gridSize + (j + 1)].painted);
hiddenFaces["front"] = (layerIndex > 0 &&
sprite.layers[layerIndex - 1].cells[cellIndex] &&
sprite.layers[layerIndex - 1].cells[cellIndex].painted);
hiddenFaces["back"] = (layerIndex < sprite.layers.length - 1 &&
sprite.layers[layerIndex + 1].cells[cellIndex] &&
sprite.layers[layerIndex + 1].cells[cellIndex].painted);

// Determinamos si la celda se va a texturizar
let isTextured = cell.textured && cell.texture;

// Generamos los triángulos, pasando "isTextured" para que se calculen UV si corresponde
let triangles = createRoundedCubeTriangles(x, y, z, scale, rounding, i * gridSize + j, layerIndex, color, hiddenFaces, isTextured);

triangles.forEach(tri => cubeMesh.push(tri));
return cubeMesh;
}


function initializeSprites3D(currentSpriteIndex) {
let sprite = sprites[currentSpriteIndex];
let spriteIndex = currentSpriteIndex;
let gridSize = sprite.gridSize;
let scale = baseResolution / gridSize / 2;

// Acumuladores para triángulos sin textura
let verticesNoText = [];
let colorsNoText = [];

// Acumulador para triángulos texturizados agrupados por id de textura
// Formato: { [textureId]: { vertices: [], colors: [], uvs: [] } }
let texturedGroups = {};

// Calcular offsets para centrar el grid en X y Y
let offsetX = ((gridSize - 1) * scale) * cellSpacingFactor / 2 - scale / 2;
let offsetY = ((gridSize - 1) * scale) * cellSpacingFactor / 2 + scale;

sprite.layers.forEach((layer, layerIndex) => {
let layerZOffset = scale * layerIndex * cellSpacingFactor - scale * sprite.layers.length / 2;
for (let i = 0; i < gridSize; i++) {
for (let j = 0; j < gridSize; j++) {
let cellIndex = i * gridSize + j;
let cell = layer.cells[cellIndex];
let cubeTriangles = drawCube(
cell,
i,
j,
layerIndex,
gridSize,
scale,
cellSpacingFactor,
offsetX,
offsetY,
layerZOffset,
sprite.layers,
layer,
sprite,
cellIndex
);
if (!cubeTriangles) continue;
// Si la celda tiene texturizado y los triángulos poseen UVs, agrupar en texturedGroups
if (cell.textured && cell.texture) {
let textureId = cell.texture;
if (!texturedGroups[textureId]) {
texturedGroups[textureId] = { vertices: [], colors: [], uvs: [] };
}
cubeTriangles.forEach(triangle => {
triangle.forEach(vertex => {
texturedGroups[textureId].vertices.push(vertex.x, vertex.y, vertex.z);
});
// Se asume el mismo color para los 3 vértices del triángulo
for (let k = 0; k < 3; k++) {
texturedGroups[textureId].colors.push(
triangle.baseColor.r / 255,
triangle.baseColor.g / 255,
triangle.baseColor.b / 255
);
}
if (triangle.uvs) {
triangle.uvs.forEach(uv => {
texturedGroups[textureId].uvs.push(uv.u, uv.v);
});
}
});
} else {
// Caso sin texturizado: acumular vértices y colores
cubeTriangles.forEach(triangle => {
triangle.forEach(vertex => {
verticesNoText.push(vertex.x, vertex.y, vertex.z);
});
for (let k = 0; k < 3; k++) {
colorsNoText.push(
triangle.baseColor.r / 255,
triangle.baseColor.g / 255,
triangle.baseColor.b / 255
);
}
});
}
}
}
});

// Crear malla para los triángulos sin textura
if (verticesNoText.length > 0) {
const geometryNoText = new THREE.BufferGeometry();
geometryNoText.setAttribute('position', new THREE.BufferAttribute(new Float32Array(verticesNoText), 3));
geometryNoText.setAttribute('color', new THREE.BufferAttribute(new Float32Array(colorsNoText), 3));
geometryNoText.computeVertexNormals();

const materialNoText = new THREE.MeshStandardMaterial({
vertexColors: true,
side: THREE.DoubleSide,
roughness: roughnessValue,
metalness: metalnessValue
});
const meshNoText = new THREE.Mesh(geometryNoText, materialNoText);
meshNoText.name = spriteIndex;
// Agregamos la propiedad spriteIndex al mesh
meshNoText.spriteIndex = currentSpriteIndex;
meshNoText.position.set(0, 0, 0);
meshNoText.scale.set(scale, scale, scale);
meshNoText.interactive = true;
meshNoText.visible = false;
sprites3d.push(meshNoText);
scene.add(meshNoText);
}

// Crear mallas para cada grupo texturizado
for (let textureId in texturedGroups) {
let group = texturedGroups[textureId];
const geometryText = new THREE.BufferGeometry();
geometryText.setAttribute('position', new THREE.BufferAttribute(new Float32Array(group.vertices), 3));
geometryText.setAttribute('color', new THREE.BufferAttribute(new Float32Array(group.colors), 3));
geometryText.setAttribute('uv', new THREE.BufferAttribute(new Float32Array(group.uvs), 2));
geometryText.computeVertexNormals();

// Buscar el objeto de textura basado en id (se asume que "texturas" es un array de objetos con id y gifDataUrl)
let textureObj = texturas.find(tex => tex.id === textureId);
let textureMap = null;
if (textureObj && textureObj.gifDataUrl) {
const loader = new THREE.TextureLoader();
textureMap = loader.load(textureObj.gifDataUrl, function(texture) {
texture.magFilter = THREE.NearestFilter;
texture.minFilter = THREE.NearestFilter;
});
}

const materialText = new THREE.MeshStandardMaterial({
map: textureMap,
vertexColors: false,
side: THREE.DoubleSide,
roughness: roughnessValue,
metalness: metalnessValue
});

const meshText = new THREE.Mesh(geometryText, materialText);
// Se asigna el nombre con el índice y el id de textura
meshText.name = spriteIndex + "_" + textureId;
// Agregamos la propiedad spriteIndex al mesh
meshText.spriteIndex = currentSpriteIndex;
meshText.position.set(0, 0, 0);
meshText.scale.set(scale, scale, scale);
meshText.interactive = true;
meshText.visible = true;
sprites3d.push(meshText);
scene.add(meshText);
}
}

function loadRemainingSprites() {
for (let i = 1; i < sprites.length; i++) {
// Saltamos el sprite ya cargado (currentSpriteIndex)
//if (i === currentSpriteIndex) continue;

setTimeout(() => {
initializeSprites3D(i);

}, i * 10);
}
}


// =====================//
//= Función start =
// =====================//

let currentObject; // Definición global
let isDragging = false;
let previousMouseX = 0;

async function startThreeD() {

if (!isThreeDActive) {

sprites3d = [];
currentSpriteIndex=0;
resetLights();
disableUserInteraction();

camera.position.set(0, 0, -500);
camera.lookAt(0, 0, 0);

setTimeout(() => {
isThreeDActive = true;
canvas2D.style.display = "none";

initializeSprites3D(0);

showSprite(currentSpriteIndex);

canvasThree.style.display = "flex";
mainThree();
loadRemainingSprites();

setTimeout(() => {
enableUserInteraction();
}, 1000);
}, 10);
}
}


// =====================//
//= Función stopThreeD() =
// =====================//
async function stopThreeD() {

if (buttonControls) {
buttonControls.scrollLeft = 0;
}


isThreeDActive = false;

canvasThree.style.display="none";
canvas3D.style.display="none";
canvas2D.style.display="flex";

sprites3d=[];
spriteMesh=[];
spriteMeshes=[];

rotationX = 0;
rotationY = 0;
currentScale = 1;

velocityX = 1;
velocityY = 1;

lastSpriteIndex = currentSpriteIndex;

/*
while (scene.children.length > 0) {
scene.remove(scene.children[0]);
}
*/
window.setTimeout(function(){
for (let i = scene.children.length - 1; i >= 0; i--) {
scene.remove(scene.children[i]);
}
// Vuelve a agregar la cámara a la escena
scene.add(camera);
scene.add(ambientLight);
//scene.add(cameraLight);
scene.add(pointLight);


},10);

}

// =====================//
//= Función dispose =
// =====================//
function disposeMesh(mesh) {
mesh.geometry.dispose();
if (mesh.material.map) {
mesh.material.map.dispose();
}
mesh.material.dispose();
}

// =====================//
//= Función draw sprites() =
// =====================//
function drawSprites() {
if (!isThreeDActive) return;
showSprite(currentSpriteIndex);
}


function showSprite(index) {
sprites3d.forEach((mesh, i) => {
updateLights();
updateMaterial();


// Establecer la visibilidad del mesh del sprite
mesh.visible = (mesh.spriteIndex === index);
});
}


init();
// =====================//
//= Función mainThree() =
// =====================//
// Función principal de renderizado
function mainThree() {
if (!isThreeDActive) return;

fpsDisplay.style.display="none";
// Aplica la inercia
rotationX += velocityX;
rotationY += velocityY;

// Aplica la fricción
velocityX *= friction;
velocityY *= friction;

// Aplica la rotación y la escala a los meshes del sprite actual

for(let i=0;i<sprites3d.length;i++)
{
let mesh = sprites3d[i];

mesh.rotation.x = rotationY;
mesh.rotation.y = rotationX;
mesh.scale.set(currentScale, currentScale, currentScale);
}

// Actualiza el sprite si currentSpriteIndex ha cambiado
if (currentSpriteIndex !== lastSpriteIndex) {
// Guarda las propiedades del sprite actual
const previousRotationX = rotationX;
const previousRotationY = rotationY;
const previousScale = currentScale;

drawSprites();
lastSpriteIndex = currentSpriteIndex;

// Aplica las propiedades guardadas al nuevo sprite
rotationX = previousRotationX;
rotationY = previousRotationY;
currentScale = previousScale;
}


renderer.setPixelRatio(window.devicePixelRatio);
renderer.render(scene, camera);



requestAnimationFrame(mainThree);
}

// Inicializar y configurar el renderer


// =====================//
//= Evento resize =
// =====================//

window.addEventListener('resize', function() {
camera.aspect = window.innerWidth / window.innerHeight;
camera.updateProjectionMatrix();
renderer.setSize(window.innerWidth, window.innerHeight);
});


// =====================//
//= Eventos táctiles =
// =====================//


let currentScale = 1;
let minScale = 0.5;
let maxScale = viewSize;
const gridBase = 9; // tamaño de cuadrícula base



function updateScale(gridActual) {
// Calculamos un factor de escala relativo basado en el tamaño de la cuadrícula
let factorEscala = gridBase / gridActual;

if (window.innerWidth > window.innerHeight) {
// Modo horizontal
currentScale = 0.8 * factorEscala;
minScale = 0.5 * factorEscala;
maxScale = viewSize * factorEscala;
} else {
// Modo vertical
currentScale = 1 * factorEscala;
minScale = 0.5 * factorEscala;
maxScale = viewSize* factorEscala;
}

// Aquí aplicas currentScale, minScale y maxScale a tus objetos 3D
// Por ejemplo: objeto3D.scale.set(currentScale, currentScale, currentScale);
}


// Detectar cambios en la orientación
window.addEventListener("resize", updateScale(gridSize));

// También actualizar al cargar la página
updateScale(gridSize);



let touchStartX, touchStartY; let rotationX = 0, rotationY = 0; let velocityX = 0; 
// Velocidad angular en el eje X 
let velocityY = 0; 
// Velocidad angular en el eje Y 
const friction = 0.9; 
// Factor de fricción let 
isZooming = false;
// Bandera para indicar si se está haciendo zoom

// Factores de sensibilidad 
let rotationFactor = 0.005; // Sensibilidad de la rotación (radianes por píxel) 
let translationFactor = 5; 
// Factor de traslación let 
zoomFactor = 5; 
// Factor de zoom 
let pinchThreshold = 60; 
// Umbral para detectar un pinch

// Variables globales para el control de gestos 
let lastTouchX = null, lastTouchY = null; 
let initialPinchDistance = null; 
let initialTwoFingerAvg = null; 
let isPinching = false; 
let ignoreSingleTouch = false;


document.addEventListener('touchstart',function(event){ 
if (event.touches.length === 2){ initialPinchDistance = Math.hypot( event.touches[0].clientX - event.touches[1].clientX, event.touches[0].clientY - event.touches[1].clientY ); 
isZooming = true; 
// Reiniciamos los datos de swipe 
touchStartX = null; touchStartY = null; velocityX = 0; 
velocityY = 0; 

} 
else if (event.touches.length === 1) 
{ 
// Si comienza un toque único, reiniciamos las velocidades 
touchStartX = event.touches[0].clientX; touchStartY = event.touches[0].clientY; velocityX = 0; velocityY = 0; 
// Aseguramos que no estemos en modo zoom 
isZooming = false; 

} 

});

document.addEventListener('touchmove', function(event) { 
if (event.touches.length === 2 && initialPinchDistance !== null) 
{ 
const currentPinchDistance = Math.hypot( event.touches[0].clientX - event.touches[1].clientX, event.touches[0].clientY - event.touches[1].clientY ); 
const scaleFactor = currentPinchDistance / initialPinchDistance; currentScale *= scaleFactor; currentScale = Math.max(minScale, Math.min(maxScale, currentScale)); initialPinchDistance = currentPinchDistance; 

}
else if ( event.touches.length === 1 && touchStartX !== null && touchStartY !== null && !isZooming ) 
{ 
const deltaX = event.touches[0].clientX - touchStartX;
const deltaY = event.touches[0].clientY - touchStartY; 
// Calcula las velocidades angulares 
velocityX = deltaX * 0.01; velocityY = deltaY * 0.01; touchStartX = event.touches[0].clientX; touchStartY = event.touches[0].clientY; 

} 

});

document.addEventListener('touchend', function(event){ // Si ya no hay dos dedos, reseteamos el estado de zoom y las velocidades. 
if (event.touches.length < 2) { 
initialPinchDistance = null; 
isZooming = false; 
// Reseteamos las velocidades para evitar swipe residual 
velocityX = 0; 
velocityY = 0; 

} 
if (event.touches.length === 0) 
{ 
touchStartX = null; touchStartY = null; 

} 

});


// Inicia el arrastre con el botón izquierdo del mouse
document.addEventListener('mousedown', function(event) {
// Solo consideramos el botón izquierdo (0)
if (event.button === 0) {
isDragging = true;
lastMouseX = event.clientX;
lastMouseY = event.clientY;
// Reiniciamos las velocidades
velocityX = 0;
velocityY = 0;
}
});

// Actualiza el arrastre en movimiento
document.addEventListener('mousemove', function(event) {
if (isDragging && lastMouseX !== null && lastMouseY !== null) {
const deltaX = event.clientX - lastMouseX;
const deltaY = event.clientY - lastMouseY;
// Calcula velocidades (puedes ajustar el factor de 0.01 según convenga)
velocityX = deltaX * 0.01;
velocityY = deltaY * 0.01;
// Actualiza la posición base para el siguiente cálculo
lastMouseX = event.clientX;
lastMouseY = event.clientY;

// Aquí podrías aplicar estos cambios para mover un elemento, por ejemplo:
// elemento.style.transform = `translate(${nuevaX}px, ${nuevaY}px) scale(${currentScale})`;
}
});

// Finaliza el arrastre al soltar el botón
document.addEventListener('mouseup', function(event) {
isDragging = false;
lastMouseX = null;
lastMouseY = null;
// Resetea las velocidades para evitar efectos residuales
velocityX = 0;
velocityY = 0;
});

// Evento para el zoom utilizando la rueda del mouse
document.addEventListener('wheel', function(event) {
event.preventDefault(); // Evita el scroll por defecto de la página
// Calcula la cantidad de zoom en función de deltaY y el factor de zoom
let zoomAmount = event.deltaY * -0.01 * zoomFactor;
currentScale += zoomAmount;
// Limita la escala al rango permitido
currentScale = Math.max(minScale, Math.min(maxScale, currentScale));

// Aplica el zoom al elemento deseado, por ejemplo:
// elemento.style.transform = `scale(${currentScale})`;
});


/*
document.addEventListener('touchstart', function(event) {
const touches = event.touches || [];

if (touches.length === 1) {
if (ignoreSingleTouch) return; // Ignorar si ya hay un gesto de dos dedos
touchStartX = touches[0].clientX;
touchStartY = touches[0].clientY;
velocityX = 0; // Reiniciar la velocidad angular
velocityY = 0;
} else if (touches.length === 2) {
const touch1 = touches[0];
const touch2 = touches[1];
initialPinchDistance = Math.hypot(
touch1.clientX - touch2.clientX,
touch1.clientY - touch2.clientY
);
initialTwoFingerAvg = {
x: (touch1.clientX + touch2.clientX) / 2,
y: (touch1.clientY + touch2.clientY) / 2
};
ignoreSingleTouch = true; // Ignorar gestos de un solo dedo
lastTouchX = null;
lastTouchY = null;
isPinching = false;
}
});

document.addEventListener('touchmove', function(event) {
const touches = event.touches || [];

if (touches.length === 2) {
let touch1 = touches[0];
let touch2 = touches[1];
let currentPinchDistance = Math.hypot(
touch1.clientX - touch2.clientX,
touch1.clientY - touch2.clientY
);
let pinchDelta = currentPinchDistance - initialPinchDistance;

if (Math.abs(pinchDelta) > pinchThreshold) {
isPinching = true;
// Manejo de zoom
camera.updateMatrixWorld();
let forward = new THREE.Vector3();
camera.getWorldDirection(forward);
camera.position.add(forward.multiplyScalar(pinchDelta * zoomFactor));
initialPinchDistance = currentPinchDistance;

} else if (!isPinching) {
const currentTwoFingerAvg = {
x: (touch1.clientX + touch2.clientX) / 2,
y: (touch1.clientY + touch2.clientY) / 2
};
const deltaX = currentTwoFingerAvg.x - initialTwoFingerAvg.x;
const deltaY = currentTwoFingerAvg.y - initialTwoFingerAvg.y;

// Traslación
camera.updateMatrixWorld();
const forward = new THREE.Vector3();
camera.getWorldDirection(forward);
const right = new THREE.Vector3().crossVectors(forward, camera.up).normalize();
const up = new THREE.Vector3().copy(camera.up).normalize();

camera.position.addScaledVector(right, -deltaX * translationFactor);
camera.position.addScaledVector(up, deltaY * translationFactor);
initialTwoFingerAvg = currentTwoFingerAvg;
}

} else if (touches.length === 1 && !isZooming && !isPinching) {
const deltaX = touches[0].clientX - touchStartX;
const deltaY = touches[0].clientY - touchStartY;

// Calcula las velocidades angulares
velocityX = deltaX * rotationFactor;
velocityY = deltaY * rotationFactor;

// Actualiza las rotaciones
rotationX += velocityX;
rotationY += velocityY;

// Reinicia la posición inicial del toque
touchStartX = touches[0].clientX;
touchStartY = touches[0].clientY;
}
});

document.addEventListener('touchend', function(event) {
const touches = event.touches || [];
if (touches.length < 2) {
initialPinchDistance = null;
initialTwoFingerAvg = null;
isPinching = false;
}
if (touches.length === 0) {
lastTouchX = null;
lastTouchY = null;
ignoreSingleTouch = false; // Permitir gestos de un solo dedo nuevamente
}
});
*/


//DOWNLOAD

let isDownloading = false;

/*
async function downloadGLTF() {
// Deshabilitar la interacción del usuario durante la descarga
disableUserInteraction();

// Seleccionar solo el sprite actual utilizando currentSpriteIndex
const spriteMeshes = sprites3d[currentSpriteIndex];
if (!spriteMeshes || spriteMeshes.length === 0) {
console.warn(`No se encontraron meshes para el sprite índice ${currentSpriteIndex}.`);
enableUserInteraction();
return;
}

// Crear la estructura básica del GLTF
const gltf = {
asset: {
version: "2.0",
generator: "Custom Script"
},
scenes: [{
nodes: [0]
}],
nodes: [],
meshes: [],
accessors: [],
bufferViews: [],
buffers: [{
byteLength: 0,
uri: "data:application/octet-stream;base64,"
}],
materials: [{ // Agregar material
pbrMetallicRoughness: {
baseColorFactor: [1, 1, 1, 1], // Color base blanco por defecto
metallicFactor: metalnessValue,
roughnessFactor: roughnessValue
},
doubleSided: true // Asegurar que las caras se vean desde ambos lados
}]
};

let bufferData = new Uint8Array(0);
let bufferByteOffset = 0;

function addBufferData(data, type, componentType) {
const dataLength = data.length * (componentType === 5126 ? 4 : 4);

const newData = new Uint8Array(bufferData.byteLength + dataLength);
newData.set(bufferData);
const dataView = new Float32Array(newData.buffer, bufferData.byteLength, data.length);
dataView.set(data);

bufferData = newData;

const bufferView = {
buffer: 0,
byteOffset: bufferByteOffset,
byteLength: dataLength
};

const accessor = {
bufferView: gltf.bufferViews.length,
componentType: componentType,
count: data.length / (type === "VEC3" ? 3 : 4),
type: type
};

gltf.bufferViews.push(bufferView);
gltf.accessors.push(accessor);
bufferByteOffset += dataLength;

return gltf.accessors.length - 1;
}

spriteMeshes.forEach((mesh, index) => {
if (mesh instanceof THREE.Mesh) {
const geometry = mesh.geometry;
const positions = geometry.attributes.position.array;
const colors = geometry.attributes.color.array;
const indices = geometry.index ? geometry.index.array : null;

const positionAccessor = addBufferData(positions, "VEC3", 5126);
const colorAccessor = addBufferData(colors, "VEC3", 5126); // Cambiado a VEC3

const primitive = {
attributes: {
POSITION: positionAccessor,
COLOR_0: colorAccessor
},
material: 0 // Referencia al material
};

if (indices) {
const indexAccessor = addBufferData(indices, "SCALAR", 5125);
primitive.indices = indexAccessor;
}

gltf.meshes.push({ primitives: [primitive] });
gltf.nodes.push({ mesh: gltf.meshes.length - 1 });
gltf.scenes[0].nodes.push(gltf.nodes.length - 1);
}
});

gltf.buffers[0].byteLength = bufferData.byteLength;

let binaryString = "";
const chunkSize = 1024;
for (let i = 0; i < bufferData.length; i += chunkSize) {
const chunk = bufferData.subarray(i, i + chunkSize);
binaryString += String.fromCharCode.apply(null, chunk);
}
gltf.buffers[0].uri += btoa(binaryString);

const gltfJSON = JSON.stringify(gltf);
const blob = new Blob([gltfJSON], { type: 'model/gltf+json' });
const url = URL.createObjectURL(blob);

const a = document.createElement('a');
a.href = url;
a.download = `sprite_${currentSpriteIndex}.gltf`;
document.body.appendChild(a);
a.click();
document.body.removeChild(a);

enableUserInteraction();
}

*/

async function downloadGLTF() {
disableUserInteraction();

let currentSpriteMeshes = sprites3d.filter(mesh => mesh instanceof THREE.Mesh);
if (!currentSpriteMeshes || currentSpriteMeshes.length === 0) {
console.warn(`No se encontraron meshes para el sprite actual.`);
enableUserInteraction();
return;
}

const gltf = {
asset: {
version: "2.0",
generator: "Custom Script"
},
scenes: [{ nodes: [] }],
nodes: [],
meshes: [],
accessors: [],
bufferViews: [],
buffers: [{ byteLength: 0, uri: "data:application/octet-stream;base64," }],
materials: [],
images: [],
textures: []
};

const materialMap = {};
let bufferData = new Uint8Array(0);
let bufferByteOffset = 0;

function addBufferData(data, type, componentType, isIndex = false) {
const dataLength = data.length * (componentType === 5126 ? 4 : 4);
const newData = new Uint8Array(bufferData.byteLength + dataLength);
newData.set(bufferData);
const dataView = new Float32Array(newData.buffer, bufferData.byteLength, data.length);
dataView.set(data);
bufferData = newData;
const bufferView = {
buffer: 0,
byteOffset: bufferByteOffset,
byteLength: dataLength,
target: isIndex ? 34963 : 34962
};
const accessor = {
bufferView: gltf.bufferViews.length,
componentType: componentType,
count: data.length / (type === "VEC3" ? 3 : (type === "VEC2" ? 2 : 1)),
type: type,
min: [],
max: []
};

// Calcular min y max para los accessors de posición
if (type === "VEC3") {
const min = [];
const max = [];
for (let i = 0; i < data.length; i += 3) {
min[0] = Math.min(min[0] || data[i], data[i]);
min[1] = Math.min(min[1] || data[i + 1], data[i + 1]);
min[2] = Math.min(min[2] || data[i + 2], data[i + 2]);
max[0] = Math.max(max[0] || data[i], data[i]);
max[1] = Math.max(max[1] || data[i + 1], data[i + 1]);
max[2] = Math.max(max[2] || data[i + 2], data[i + 2]);
}
accessor.min = min;
accessor.max = max;
}

gltf.bufferViews.push(bufferView);
gltf.accessors.push(accessor);
bufferByteOffset += dataLength;
return gltf.accessors.length - 1;
}

gltf.materials.push({
name: "defaultMaterial",
pbrMetallicRoughness: {
baseColorFactor: [1, 1, 1, 1],
metallicFactor: metalnessValue,
roughnessFactor: roughnessValue
},
doubleSided: true
});
materialMap["default"] = 0;

currentSpriteMeshes.forEach((mesh) => {
if (mesh instanceof THREE.Mesh) {
const geometry = mesh.geometry;
const positions = geometry.attributes.position.array;
const colors = geometry.attributes.color.array;

const positionAccessor = addBufferData(positions, "VEC3", 5126);
const colorAccessor = addBufferData(colors, "VEC3", 5126);

const primitiveAttributes = {
POSITION: positionAccessor,
COLOR_0: colorAccessor
};

if (geometry.attributes.uv) {
const uvs = geometry.attributes.uv.array;
const uvAccessor = addBufferData(uvs, "VEC2", 5126);
primitiveAttributes.TEXCOORD_0 = uvAccessor;
}

let primitive = {
attributes: primitiveAttributes,
material: 0
};

if (geometry.index) {
const indices = geometry.index.array;
const indexAccessor = addBufferData(indices, "SCALAR", 5125, true);
primitive.indices = indexAccessor;
}

let hasTexture = false;
let textureId = null;
if (mesh.material && mesh.material.map && mesh.material.map.name) {
hasTexture = true;
textureId = mesh.material.map.name;
}

if (hasTexture) {
if (materialMap[textureId] === undefined) {
const textureObj = texturas.find(tex => tex.id === textureId);
if (textureObj && textureObj.image) {
const dataUrl = convertToDataURL(textureObj.image); // Convertir a PNG
gltf.images.push({
uri: dataUrl,
name: textureObj.id
});
const imageIndex = gltf.images.length - 1;
gltf.textures.push({ source: imageIndex });
const textureIndex = gltf.textures.length - 1;

const newMaterial = {
name: `mat_${textureId}`,
pbrMetallicRoughness: {
baseColorTexture: {
index: textureIndex
},
metallicFactor: metalnessValue,
roughnessFactor: roughnessValue
},
doubleSided: true
};
gltf.materials.push(newMaterial);
materialMap[textureId] = gltf.materials.length - 1;
}
}
primitive.material = materialMap[textureId];
} else {
primitive.material = materialMap["default"];
}

gltf.meshes.push({ primitives: [primitive] });
gltf.nodes.push({ mesh: gltf.meshes.length - 1 });
gltf.scenes[0].nodes.push(gltf.nodes.length - 1);
}
});

gltf.buffers[0].byteLength = bufferData.byteLength;

let binaryString = "";
const chunkSize = 1024;
for (let i = 0; i < bufferData.length; i += chunkSize) {
const chunk = bufferData.subarray(i, i + chunkSize);
binaryString += String.fromCharCode.apply(null, chunk);
}
gltf.buffers[0].uri += btoa(binaryString);

const gltfJSON = JSON.stringify(gltf);
const blob = new Blob([gltfJSON], { type: 'model/gltf+json' });
const url = URL.createObjectURL(blob);

const a = document.createElement('a');
a.href = url;
a.download = `sprite_${currentSpriteIndex}.gltf`;
document.body.appendChild(a);
a.click();
document.body.removeChild(a);

enableUserInteraction();
}

function convertToDataURL(image, format = 'image/png') {
const canvas = document.createElement('canvas');
const ctx = canvas.getContext('2d');
canvas.width = image.width;
canvas.height = image.height;
ctx.drawImage(image, 0, 0);
return canvas.toDataURL(format);
}






// Función para alternar la visibilidad del menú
document.getElementById('menuButton3DLights').onclick = function(event) {
let menu3DLights = document.getElementById('menu3DLights');
if (menu3DLights.style.display === 'none' || menu3DLights.style.display === '') {
menu3DLights.style.display = 'block'; 
if(isPlaying)
{
togglePlayPause();
}

} else {
menu3DLights.style.display = 'none';

}
event.stopPropagation();
};

/*
document.getElementById('menuButton3DShape').onclick = function(event) {
let menu3DShape = document.getElementById('menu3DShape');
if (menu3DShape.style.display === 'none' || menu3DShape.style.display === '') {
menu3DShape.style.display = 'block'; 
if (isPlaying)
{
togglePlayPause();
}

} else {
menu3DShape.style.display = 'none';

}
event.stopPropagation();
};
*/



