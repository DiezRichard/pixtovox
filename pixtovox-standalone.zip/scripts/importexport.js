 function getCurrentProject() {
return new Promise((resolve) => {
const projects = JSON.parse(localStorage.getItem("pixtovoxAssetProjects")) || [];
const project = projects.find(p => p.id === currentProjectID);
resolve(project || null);
});
}

//=======================================
//=== IMPORTAR PROYECTO DESDE JSON ===
//=======================================
let outputProject = document.getElementById("outputProject");

document.getElementById("importProject").addEventListener("click", () => {
  



document.getElementById("importFile").click();
});

document.getElementById("importFile").addEventListener("change", (event) => {
const file = event.target.files[0];
if (!file) return;

const reader = new FileReader();
reader.onload = async (e) => {
try {
// Se parsea el JSON; se espera que tenga la nueva estructura de proyecto
const importedProject = JSON.parse(e.target.result);
const projects = await getAllProjects();

// Verificar si ya existe un proyecto con el mismo ID
const exists = projects.some(p => p.id === importedProject.id);
if (exists) {
mostrarMensaje("El proyecto ya existe en la base de datos.", "outputProject");
return;
}

// Agregar el proyecto importado y actualizar la base de datos (por ejemplo, en localStorage)
projects.push(importedProject);
localStorage.setItem("pixtovoxAssetProjects", JSON.stringify(projects));
mostrarMensaje("Proyecto importado con éxito.", "outputProject");
loadProjectList();

} catch (error) {
mostrarMensaje("Error al importar el archivo. Asegúrate de que sea un JSON válido.", "outputProject");
}
};

reader.readAsText(file);
loadProjectList();
});


/*
//=== FUNCIÓN PARA GENERAR UN ARCHIVO OBJ POR SPRITE ===//
function generarArchivoOBJ(spriteMesh) {
    let objContent = "# Archivo OBJ generado desde un sprite 3D\n\n";
    let vertexIndex = 1;
    let vertices = [];
    let faces = [];

    spriteMesh.forEach((mesh) => {
        let { x, y, z } = mesh.position;
        
      mesh.scale*=2;
        let scale = mesh.scale; // Mantiene la escala original

        // Generar los 8 vértices del cubo con la escala correcta
        let v1 = `v ${x / scale} ${y / scale} ${z / scale}`;
        let v2 = `v ${(x + scale) / scale} ${y / scale} ${z / scale}`;
        let v3 = `v ${x / scale} ${(y - scale) / scale} ${z / scale}`;
        let v4 = `v ${(x + scale) / scale} ${(y - scale) / scale} ${z / scale}`;
        let v5 = `v ${x / scale} ${y / scale} ${(z + scale) / scale}`;
        let v6 = `v ${(x + scale) / scale} ${y / scale} ${(z + scale) / scale}`;
        let v7 = `v ${x / scale} ${(y - scale) / scale} ${(z + scale) / scale}`;
        let v8 = `v ${(x + scale) / scale} ${(y - scale) / scale} ${(z + scale) / scale}`;

        vertices.push(v1, v2, v3, v4, v5, v6, v7, v8);

        // Definir las caras del cubo (en triángulos)
        let f1 = `f ${vertexIndex} ${vertexIndex + 1} ${vertexIndex + 2}`;
        let f2 = `f ${vertexIndex + 1} ${vertexIndex + 3} ${vertexIndex + 2}`;
        let f3 = `f ${vertexIndex + 4} ${vertexIndex + 5} ${vertexIndex + 6}`;
        let f4 = `f ${vertexIndex + 5} ${vertexIndex + 7} ${vertexIndex + 6}`;
        let f5 = `f ${vertexIndex} ${vertexIndex + 1} ${vertexIndex + 4}`;
        let f6 = `f ${vertexIndex + 1} ${vertexIndex + 5} ${vertexIndex + 4}`;
        let f7 = `f ${vertexIndex + 2} ${vertexIndex + 3} ${vertexIndex + 6}`;
        let f8 = `f ${vertexIndex + 3} ${vertexIndex + 7} ${vertexIndex + 6}`;
        let f9 = `f ${vertexIndex} ${vertexIndex + 2} ${vertexIndex + 4}`;
        let f10 = `f ${vertexIndex + 2} ${vertexIndex + 6} ${vertexIndex + 4}`;
        let f11 = `f ${vertexIndex + 1} ${vertexIndex + 3} ${vertexIndex + 5}`;
        let f12 = `f ${vertexIndex + 3} ${vertexIndex + 7} ${vertexIndex + 5}`;

        faces.push(f1, f2, f3, f4, f5, f6, f7, f8, f9, f10, f11, f12);

        vertexIndex += 8; // Se incrementa el índice de vértices
    });

    objContent += vertices.join("\n") + "\n";
    objContent += faces.join("\n") + "\n";

    return objContent;
}
*/

// DATA TO URL
function dataURLtoBlob(dataurl) {
const arr = dataurl.split(',');
const mime = arr[0].match(/:(.*?);/)[1];
const bstr = atob(arr[1]);
let n = bstr.length;
const u8arr = new Uint8Array(n);
while (n--) {
u8arr[n] = bstr.charCodeAt(n);
}
return new Blob([u8arr], { type: mime });
}


//=== FUNCIÓN PARA DESCARGAR ARCHIVOS ===//
function descargarArchivo(blob, nombre) {
const link = document.createElement("a");
link.href = URL.createObjectURL(blob);
link.download = nombre;
document.body.appendChild(link);
link.click();
document.body.removeChild(link);
}


//============================
//=DESCARGAR PROYECTO EN ZIP=
//============================
async function descargarProyecto() {

mostrarMensaje("Iniciando la descarga del proyecto...", "outputProject");

try {
const zip = new JSZip();

// 1. Obtener el proyecto actual
const project = await getCurrentProject();
if (!project) {
mostrarMensaje("No se encontró el proyecto.","outputProject");
return;
}

// 2. Crear el archivo JSON del proyecto
const jsonString = JSON.stringify(project, null, 2);
zip.file(`proyecto_${project.id}.json`, jsonString);




// 5. Obtener y agregar los sprites PNG dentro de una carpeta en el ZIP
const spritesFolder = await downloadAllSprites();
if (spritesFolder) {
Object.entries(spritesFolder).forEach(([filename, fileBlob]) => {
zip.file(`sprites/${filename}`, fileBlob);
});
} else {
console.error("No se pudieron agregar los sprites PNG.");
}

// 6. Generar el GIF
const gifBlob = await generateThumbnail(sprites);
if (gifBlob instanceof Blob) {
zip.file("animacion.gif", gifBlob);
} else {
console.error("Error al generar el GIF.");
mostrarMensaje("Error al generar el GIF. No se incluirá en el ZIP.","outputProject");
}

// 7. Generar y descargar el ZIP final
const zipBlob = await zip.generateAsync({ type: "blob" });
descargarArchivo(zipBlob, `proyecto_${project.id}.zip`);

outputProject.innerHTML = "<p>¡Proyecto descargado correctamente en un ZIP!</p>";
} catch (error) {
console.error("Error durante la descarga del proyecto:", error);

outputProject.innerHTML = `<p>Error: ${error.message}</p>`;
}
}



