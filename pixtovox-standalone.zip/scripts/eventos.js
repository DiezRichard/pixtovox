
// ============================
// === Eventos ===
// ============================
playPauseButton.addEventListener("click", togglePlayPause);



//===DESACTIVAR PINCH ZOOM===//
document.addEventListener('touchmove', function(e) {
if (e.touches.length > 1) {
e.preventDefault();
}
}, { passive: false });


function desactivarTouchMove() {
document.removeEventListener("touchmove", prevenirRecarga, { passive: false });
document.body.style.overflow = "hidden"; // Bloquea el scroll completamente
}

function activarTouchMove() {
document.addEventListener("touchmove", prevenirRecarga, { passive: false });
document.body.style.overflow = "auto"; // Reactiva el scroll
}



function prevenirRecarga(event){
  if (window.scrollY === 0 && event.touches.length > 0 && event.touches[0].clientY > 0) {
    event.preventDefault();
  }
}

// Agrega un listener para el evento 'touchstart' al documento



//===========================
//=== Evento al Cambiar Pantalla ===
//===========================//
function mostrarPantallaProyectos() {
  
  //activarTouchMove();
//desactivarTouchMove(); // Desactiva la restricción de scroll
fadeInProjectScreen(); // Lógica de tu pantalla de proyectos
}

function ocultarPantallaProyectos() {
//activarTouchMove(); // Reactiva la restricción de scroll
}




const tooltip = document.getElementById('tooltip');
const elements = document.querySelectorAll('.hover-element');

let tooltipTimeout; // Variable para el temporizador

elements.forEach(element => {
element.addEventListener('touchstart', (event) => {
tooltip.textContent = element.getAttribute('data-description');
tooltip.style.display = 'block';

// Obtener la posición del cursor
const touchX = event.touches[0].pageX;
const touchY = event.touches[0].pageY;
const tooltipWidth = tooltip.offsetWidth;
const windowWidth = window.innerWidth;


});

element.addEventListener('pointerup', () => {
//clearTimeout(tooltipTimeout); // Limpiar el temporizador si se suelta antes de tiempo
tooltip.style.display = 'none'; // Ocultar el tooltip
});

element.addEventListener('pointercancel', () => {
//clearTimeout(tooltipTimeout); // Limpiar el temporizador si se suelta antes de tiempo
tooltip.style.display = 'none'; // Ocultar el tooltip
});

});

document.addEventListener("keydown", (event) => {
if (event.code === "Space") { // Verifica si la tecla es la barra espaciadora
event.preventDefault(); // Previene el comportamiento predeterminado (como el desplazamiento de la página)
togglePlayPause(); // Llama a la función togglePlayPause
}
});

document.addEventListener("keydown", (event) => {
if (event.ctrlKey && event.code === "KeyS") { // Verifica si Ctrl está presionado y la tecla S
event.preventDefault(); // Previene el comportamiento predeterminado del navegador (guardar la página)
saveProjectHandler(); // Llama a la función saveProjectHandler
}
});

document.onclick = function(event) {
var parent = window.parent; // Accede a la ventana principal

// Verifica si el menú está en el DOM de la página principal
var menu = parent.document.getElementById('menu');
if (menu && menu.style.display === 'block') {
menu.style.display = 'none'; // Ocultar menú si se hace clic fuera de él
}
};

window.addEventListener('resize', function() {
  camera.fov = getFovBasedOnOrientation();
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
  
  if (buttonControls) {
  buttonControls.scrollLeft = 0;
}

});


grid.addEventListener('pointerdown', () => {
  
  if(isPlaying)
  {
    togglePlayPause();
    
    setTimeout(() => {
  grid.children.style.pointerEvents="auto";
}, 10);
  }
});


/*
document.addEventListener('touchstart', function(event){
  // Comprueba si el toque inicial ocurrió dentro de un elemento scrollable
  const isScrollable = event.target.classList.contains('scrollable') ||
                       event.target.closest('.scrollable');

  // Si el toque no fue dentro de un elemento scrollable, previene el scroll de la página
  if (!isScrollable) {
    document.body.classList.add('prevent-overscroll');
  }
});

document.addEventListener('touchmove', function(event){
  // Si la clase 'prevent-overscroll' está activa, previene el comportamiento predeterminado del scroll
  if (document.body.classList.contains('prevent-overscroll')) {
    event.preventDefault();
  }
}, { passive: false }); // passive: false es necesario para poder prevenir el evento

document.addEventListener('touchend', function(){
  // Elimina la clase para permitir el scroll nuevamente
  document.body.classList.remove('prevent-overscroll');
});
*/

(function() {
  if (window.parent && window.parent.document) {
    var style = window.parent.document.createElement('style');
    style.type = 'text/css';
    style.innerHTML = 'html, body { overscroll-behavior: none !important; }';
    window.parent.document.head.appendChild(style);
  }
})();