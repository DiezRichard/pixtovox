self.addEventListener('message', function(e) {
  const { spriteMeshesData } = e.data;
  let objContent = "# Archivo OBJ generado desde un sprite 3D\n\n";
  let vertexIndex = 1;
  
  // Procesamos cada mesh enviado desde el hilo principal
  spriteMeshesData.forEach(meshData => {
    const { positions, colors, material } = meshData;
    // Obtener el color del primer vértice
    const colorR = colors[0];
    const colorG = colors[1];
    const colorB = colors[2];
    
    // Generar vértices con color constante
    for (let i = 0; i < positions.length; i += 3) {
      objContent += `v ${positions[i]} ${positions[i+1]} ${positions[i+2]} ${colorR} ${colorG} ${colorB}\n`;
    }
    
    // Definir las caras
    for (let i = 0; i < positions.length / 3; i += 3) {
      objContent += `f ${vertexIndex} ${vertexIndex+1} ${vertexIndex+2}\n`;
      vertexIndex += 3;
    }
    
    // Material: textura e iluminación
    if (material.mapSrc) {
      objContent += `usemtl SpriteMaterial\n`;
      objContent += `map_Kd ${material.mapSrc}\n`;
    }
    if (material.color) {
      objContent += `Kd ${material.color.r} ${material.color.g} ${material.color.b}\n`;
    }
    if (material.specular) {
      objContent += `Ks ${material.specular.r} ${material.specular.g} ${material.specular.b}\n`;
    }
    if (material.emissive) {
      objContent += `Ka ${material.emissive.r} ${material.emissive.g} ${material.emissive.b}\n`;
    }
  });
  
  // Enviar el resultado de vuelta al hilo principal
  self.postMessage({ objContent });
});
