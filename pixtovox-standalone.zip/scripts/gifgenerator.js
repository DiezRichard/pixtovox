resolution=1000;

function mergeSpriteLayers(sprite) {
let mergedCells = Array(sprite.gridSize * sprite.gridSize)
.fill(null)
.map(() => ({
painted: false,
color: gridBackgroundColor,
textured: false,
texture: null
}));

// Iterar sobre las capas en orden inverso
for (let i = sprite.layers.length - 1; i >= 0; i--) {
const layer = sprite.layers[i];
layer.cells.forEach((cell, j) => {
if (cell.painted || cell.textured) {
mergedCells[j] = { ...cell };
}
});
}
return mergedCells;
}



//==============================

function generateThumbnail(sprites) {
return new Promise((resolve) => {
const gif = new GIF({
workers: 2,
quality: 15,
width: resolution, // Tamaño reducido para los botones
height: resolution,
workerScript: "scripts/gif.worker.js",
transparent: 0x32322E,
});

let delay = 500;

// Iterar sobre cada sprite para agregar un frame al GIF
sprites.forEach((sprite) => {
const canvas = document.createElement("canvas");
const ctx = canvas.getContext("2d");
canvas.width = resolution;
canvas.height = resolution;
const scale = resolution / sprite.gridSize;

// Fondo: se pinta con el color de sacrificio
ctx.fillStyle = "#32322E";
ctx.fillRect(0, 0, canvas.width, canvas.height);

// Fusionar capas para obtener la imagen final del sprite
const mergedCells = mergeSpriteLayers(sprite);
mergedCells.forEach((cell, i) => {
const x = (i % sprite.gridSize) * scale;
const y = Math.floor(i / sprite.gridSize) * scale;

if (cell.textured && cell.texture) {
// Si la celda tiene textura, intenta dibujar la textura
let texturaData = getTexturaById(cell.texture);
//console.log(texturaData);

if (texturaData && texturaData.gifDataUrl) {
  
 console.log(texturaData.gifDataUrl);
 
let img = new Image();


  img.src = texturaData.gifDataUrl;
  
ctx.drawImage(img, x, y, scale, scale);


} else {
ctx.fillStyle = "#999";
ctx.fillRect(x, y, scale, scale);
}
} else if (cell.painted) {
ctx.fillStyle = cell.color;
ctx.fillRect(x, y, scale, scale);
}
});

gif.addFrame(canvas, { delay });
});

gif.on("finished", (blob) => {
if (blob instanceof Blob) {
resolve(blob);
} else {
console.error("Error: El GIF generado no es un Blob válido.");
resolve(null);
}
});

gif.render();
});
}






