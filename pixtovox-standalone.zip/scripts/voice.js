// Función para reproducir texto como voz con una voz de androide mujer
function speakTextWithVoice(text) {
  const utterance = new SpeechSynthesisUtterance(text);
  
  // Seleccionamos la voz de androide mujer (según disponibilidad del sistema)
  const voices = speechSynthesis.getVoices();
  const androidVoice = voices.find(voice => voice.name.toLowerCase().includes('android') && voice.name.toLowerCase().includes('female'));
  
  if (androidVoice) {
    utterance.voice = androidVoice;
  } else {
    // Si no se encuentra una voz de androide, usamos una voz predeterminada
    utterance.lang = 'en-US';
  }
  
  // Reproducir la voz sin reverb
  speechSynthesis.speak(utterance);
}

// Función para iniciar el habla con la voz de androide
function speakWithoutReverb(text) {
  speakTextWithVoice(text);
}









/*

document.getElementById('playPause').addEventListener('click', () => {
  speakWithoutReverb("Play");
});

document.getElementById('playPause').addEventListener('click', () => {
  speakWithoutReverb("Pause");
});

document.getElementById('toggle3D').addEventListener('click', () => {
  speakWithoutReverb("3D mode");
});

document.getElementById('saveProject').addEventListener('click', () => {
  speakWithoutReverb("Save Project");
});

document.getElementById('downloadProject').addEventListener('click', () => {
  speakWithoutReverb("export project");
});

document.getElementById('exit').addEventListener('click', () => {
  speakWithoutReverb("exit");
});

document.getElementById('cameraMove').addEventListener('click', () => {
  speakWithoutReverb("camera");
});


document.getElementById('increaseSpeed').addEventListener('click', () => {
  speakWithoutReverb("Speed up");
});

document.getElementById('decreaseSpeed').addEventListener('click', () => {
  speakWithoutReverb("slow down");
});

document.getElementById('duplicate').addEventListener('click', () => {
  speakWithoutReverb("duplicated");
});

document.getElementById('colorPicker').addEventListener('click', () => {
  speakWithoutReverb("select color");
});

document.getElementById('deleteSprite').addEventListener('click', () => {
  speakWithoutReverb("deleted");
});
*/