//==========================//

const gridSizeScreen = document.getElementById('gridSizeScreen');

const gridButtonContainer= document.getElementById("buttonContainer");

const mainContent = document.getElementById('mainContent');


//==========================//
//=FADE IN GRIDSIZESCREEN===//
//===========================/
function fadeInGridSizeScreen() {

gridButtonContainer.scrollTop=0;
gridButtonContainer.scrollLeft=0;

gridSizeScreen.style.display = 'flex';
gridSizeScreen.classList.remove('fade-out');
//void gridSizeScreen.offsetWidth;
gridSizeScreen.classList.add('fade-in');


} // fin fadeInInitialScreen

//==========================//
//===SetGridSize===//
//==========================//
function setGridSize(size) {

if (buttonControls) {
  buttonControls.scrollLeft = 0;
}
gridSizeScreen.classList.remove('fade-in');
gridSizeScreen.classList.add('fade-out');


setTimeout(() => {

//activarTouchMove();

gridSizeScreen.style.display = 'none';
mainContent.style.display = 'flex';
mainContent.classList.add('fade-in');
//desactivarTouchMove();

inicializar(size);

window.parent.postMessage('hideMenu', '*');

}, 800);

} // fin setGridSize

//==========================//

document.getElementById('size9x9').onclick = function() {
  gridSize = 9;
viewSize = 9;
setGridSize(9);


};

//==========================//
document.getElementById('size15x15').onclick = function() {
  gridSize = 15;
viewSize = 15;
setGridSize(15);

};

//==========================//
document.getElementById('size25x25').onclick = function() {
  gridSize = 25;
viewSize = 15;
  setGridSize(25);
  
};

//===========================//
document.getElementById('size32x32').onclick = function() {
  gridSize = 32;
viewSize = 15;
  setGridSize(32);
  
};

//===========================//
document.getElementById('size64x64').onclick = function() {
  gridSize = 64;
viewSize = 15;
  setGridSize(64);
  
};

