// ============================
// === Declaración de Variables ===
// ============================
const grid = document.getElementById("grid");
const spriteBar = document.getElementById("spriteBar"); 
const layerBar = document.getElementById("layerBar"); 
const playPauseButton = document.getElementById("playPause");
const playPause3DBtn = document.getElementById("playPause3D");
const copyButton = document.getElementById("copySprite");
const pasteButton = document.getElementById("pasteSprite");
const deleteButton = document.getElementById("deleteSprite");
const grid9x9Button = document.getElementById("grid9x9");
const grid15x15Button = document.getElementById("grid15x15");

const colorSelect = document.getElementById("colorSelect");

const increaseSpeedButton = document.getElementById("increaseSpeed");

const toggleTexturas = document.getElementById("toggleTexturas");


const panelTexturas = document.getElementById("panelTexturas");

let gridSize = 9;
let sprites = [];
let currentSpriteIndex = 0;

let isPlaying = false;
let animationInterval;
let copiedSprite = null;
let gridBackgroundColor = "rgba(70, 70, 70,0)";

let currentProjectID = null;

// Para copiar/pegar capas
let copiedLayer = null;

// Flag de modo previsualización (no editable)
// Cuando isPreviewMode es true, el grid muestra la fusión de capas (vista previa)
// y no se deben guardar sus contenidos en la capa activa.
let isPreviewMode = false;

let activeList="";



// =====================//
//= Funciones Auxiliares =
// =====================//
function rgbStringToObject(rgbString) {
let [r, g, b] = rgbString.match(/\d+/g).map(Number);
return { r, g, b };
}

function rgbToHex(rgbString) {
const digits = rgbString.match(/\d+/g);
if (!digits) return "#000000";
let r = parseInt(digits[0]).toString(16).padStart(2, "0");
let g = parseInt(digits[1]).toString(16).padStart(2, "0");
let b = parseInt(digits[2]).toString(16).padStart(2, "0");
return "#" + r + g + b;
}

//paint con fill
let currentTool = null; 
const paintFillButton = document.getElementById('paintFill');
paintFillButton.addEventListener('click', () => {
if (currentTool === 'paintFill') {
currentTool = null; 
paintFillButton.classList.remove('active-tool');
} else {
currentTool = 'paintFill'; 
paintFillButton.classList.add('active-tool');
}
});

function createGrid(size, cells = null, editable = true, grid) {
grid.innerHTML = "";
grid.style.backgroundColor = gridBackgroundColor;

let cellSize = grid.offsetWidth / viewSize;

const gridContainer = document.createElement("div");
gridContainer.style.overflow = "hidden";
gridContainer.style.position = "relative";


gridContainer.style.width = `${size * cellSize}px`;
gridContainer.style.height = `${size * cellSize}px`;
gridContainer.style.padding = "0";
gridContainer.style.margin = "0";

grid.style.width = `${grid.offsetWidth}px`;
grid.style.height = `${grid.offsetHeight}px`;

if (grid === grid) {
grid.style.overflow = "scroll";
grid.style.overflowX = "scroll";
grid.style.overflowY = "scroll";
}

grid.appendChild(gridContainer);

for (let i = 0; i < size * size; i++) {
const cell = document.createElement("div");
cell.classList.add("cell");

if (grid === viewModePanel) {
cell.style.border = "none";
cell.style.borderRadius = "0";
}
cell.style.position = "absolute";
cell.style.width = `${cellSize}px`;
cell.style.height = `${cellSize}px`;
cell.style.left = `${(i % size) * cellSize}px`;
cell.style.top = `${Math.floor(i / size) * cellSize}px`;

let cellData = cells ? { ...cells[i] } : { painted: false, color: gridBackgroundColor, textured: false, texture: null };

// Aplicar el estilo inicial basado en si tiene textura o color
if (cellData.textured && cellData.texture) {
cell.style.backgroundColor = gridBackgroundColor; // Fondo transparente
cell.style.backgroundImage = `url(${getTexturaById(cellData.texture)?.gifDataUrl || ''})`;
cell.style.backgroundSize = 'cover';
cell.dataset.textured = 'true';
cell.dataset.texture = cellData.texture;
} else {
cell.style.backgroundColor = cellData.painted ? cellData.color : gridBackgroundColor;
}

if (cellData.painted || cellData.textured) cell.classList.add("active");

if (editable && !isPlaying) {
cell.addEventListener("pointerdown", () => {
pressTimer = setTimeout(() => {
if (cell.classList.contains("active")) {
if (cellData.textured && cellData.texture) {
//console.log(currentTexture);
let element = getTexturaById(getCurrentCellColorOrTextureId(cell));

currentTexture = new Object;

currentTexture.id = element.id;
currentTexture.textura = element.gifDataUrl;
//console.log(currentTexture);
let imgTexturaBtn = document.getElementById('imgTexturaBtn');
imgTexturaBtn.src = currentTexture.textura;
colorSelect.value = null;


} else {

colorSelect.value = rgbToHex(cell.style.backgroundColor);
currentTexture = null;
}
}
}, 500);
});
cell.addEventListener("pointerup", () => clearTimeout(pressTimer));
cell.addEventListener("pointerleave", () => clearTimeout(pressTimer));

cell.addEventListener("click", (e) => {
if (!isPlaying) {
if (currentTool === 'paintFill') {
handlePaintFill(e.target, size, cells, gridBackgroundColor);

} else {
let currentSprite = sprites[currentSpriteIndex];
let layerCells = currentSprite.layers[currentSprite.currentLayerIndex].cells;

if (cell.classList.contains("active")) {
// Si la celda ya está activa (pintada o texturizada), borrarla
layerCells[i] = {
painted: false,
color: gridBackgroundColor,
textured: false,
texture: null
};
cell.classList.remove("active");
cell.style.backgroundColor = gridBackgroundColor;
cell.style.backgroundImage = '';
delete cell.dataset.textured;
delete cell.dataset.texture;
} else {
// Si la celda está vacía, pintar o texturizar
let isActive = true; // Ahora siempre se activa al pintar/texturizar
if (currentTexture && currentTexture.id) {
// Aplicar textura
layerCells[i] = {
painted: true,
color: gridBackgroundColor,
textured: true,
texture: currentTexture.id
};
cell.style.backgroundColor = gridBackgroundColor;
cell.style.backgroundImage = `url(${currentTexture.textura})`;
cell.style.backgroundSize = 'cover';
cell.dataset.textured = 'true';
cell.dataset.texture = currentTexture.id;
cell.classList.add("active");
} else {
// Aplicar color
let color = colorSelect.value;
layerCells[i] = {
painted: true,
color: color,
textured: false,
texture: null
};
cell.style.backgroundColor = color;
cell.style.backgroundImage = '';
cell.classList.add("active");
delete cell.dataset.textured;
delete cell.dataset.texture;
}
}
updateLayerBar();
updateSpriteBar();
}
}
});
}

gridContainer.appendChild(cell);
}
}


function getTexturaById(id) {


for (let textura of texturas) {
if (textura.id === id) {
return textura;
}
}
return null;
}

function handlePaintFill(startCell, size, cells, gridBackgroundColor) {
if (!startCell.classList.contains('cell')) {
return;
}

const index = Array.from(startCell.parentNode.children).indexOf(startCell);
const currentColorOrTextureId = getCurrentCellColorOrTextureId(startCell);
const targetColorOrTextureId = currentTexture && currentTexture.id ? currentTexture.id : colorSelect.value;
const applyingTexture = !!currentTexture?.id;

const currentSprite = sprites[currentSpriteIndex];
const layerIndex = currentSprite.currentLayerIndex;
const currentCellsData = currentSprite.layers[layerIndex].cells;
const newCellsData = [...currentCellsData];

const queue = [index];
const visited = new Set();

while (queue.length > 0) {
const currentIndex = queue.shift();

if (visited.has(currentIndex)) {
continue;
}
visited.add(currentIndex);

const row = Math.floor(currentIndex / size);
const col = currentIndex % size;

const currentCellElement = getCellByIndex(currentIndex, startCell.parentNode);
const currentColorOrTextureIdToCheck = getCurrentCellColorOrTextureId(currentCellElement);

const shouldProcess = currentColorOrTextureIdToCheck === currentColorOrTextureId;

if (shouldProcess) {
let newPainted = false;
let newColor = gridBackgroundColor;
let newTextured = false;
let newTexture = null;

if (targetColorOrTextureId === currentColorOrTextureId) {
} else {

newPainted = true;
if (applyingTexture) {
newColor = gridBackgroundColor;
newTextured = true;
newTexture = targetColorOrTextureId;
} else {
newColor = targetColorOrTextureId;
newTextured = false;
newTexture = null;
}
}

newCellsData[currentIndex] = { painted: newPainted, color: newColor, textured: newTextured, texture: newTexture };
currentCellElement.style.backgroundColor = newColor;
currentCellElement.style.backgroundImage = newTexture ? `url(${getTexturaById(newTexture)?.gifDataUrl || ''})` : '';
currentCellElement.style.backgroundSize = 'cover';
currentCellElement.dataset.textured = newTextured ? 'true' : '';
currentCellElement.dataset.texture = newTexture || '';
currentCellElement.classList.toggle("active", newPainted || newTextured);

const neighbors = getNeighbors(currentIndex, size);
neighbors.forEach(neighborIndex => {
if (!visited.has(neighborIndex)) {
queue.push(neighborIndex);
}
});
}
}

currentSprite.layers[layerIndex].cells = newCellsData;
updateLayerBar();
updateSpriteBar();

paintFillButton.click();
}

function getCellByIndex(index, parentElement) {
return parentElement.children[index];
}

function getNeighbors(index, size) {
const neighbors = [];
const row = Math.floor(index / size);
const col = index % size;

// Arriba
if (row > 0) neighbors.push((row - 1) * size + col);
// Abajo
if (row < size - 1) neighbors.push((row + 1) * size + col);
// Izquierda
if (col > 0) neighbors.push(row * size + (col - 1));
// Derecha
if (col < size - 1) neighbors.push(row * size + (col + 1));

return neighbors;
}

function rgbToHex(rgb) {
if (!rgb || rgb === 'transparent') return gridBackgroundColor;
const values = rgb.substring(rgb.indexOf('(') + 1, rgb.indexOf(')')).split(',');
const r = parseInt(values[0]).toString(16).padStart(2, '0');
const g = parseInt(values[1]).toString(16).padStart(2, '0');
const b = parseInt(values[2]).toString(16).padStart(2, '0');
return `#${r}${g}${b}`;
}

function getCurrentCellColorOrTextureId(cell) {
if (cell.dataset.textured === 'true' && cell.dataset.texture) {
return cell.dataset.texture; // Devolver el ID de la textura si está texturizada
}
return rgbToHex(cell.style.backgroundColor); // Devolver el color si no
}


// ==========================


window.addEventListener('resize', updateGrid());
window.addEventListener('orientationchange', updateGrid());


function updateLayerBar() {
if (is3DActive || isPlaying) return; // Bloquea cambios si está en 3D o en reproducción

layerBar.innerHTML = "";
layerBar.classList.add("active");
spriteBar.classList.remove("active");

let infoBtn = document.createElement("div");
infoBtn.textContent = "i";
infoBtn.classList.add("add-layer");
infoBtn.id = "infoBtn";
layerBar.appendChild(infoBtn);

const addLayerButton = document.createElement("div");
addLayerButton.classList.add("add-layer");
addLayerButton.textContent = "+";
addLayerButton.addEventListener("click", () => {
if (!isPlaying) addLayer();
});

layerBar.appendChild(addLayerButton);

const currentSprite = sprites[currentSpriteIndex];
currentSprite.layers.forEach((layer, index) => {
const thumbnail = document.createElement("div");
thumbnail.classList.add("layer-thumbnail");
if (index === currentSprite.currentLayerIndex) {
thumbnail.classList.add("selected");
}

// Manejo de eventos de arrastrar
thumbnail.setAttribute("draggable", "true"); // Hacer el thumbnail arrastrable

thumbnail.addEventListener("dragstart", (event) => {
if (!isPlaying) {
event.dataTransfer.setData("text/plain", index); // Guardar el índice de la capa
thumbnail.style.opacity = "0.9"; // Aplicar opacidad mientras se arrastra

setTimeout(() => {
//thumbnail.style.display = "none"; // Ocultar el elemento arrastrado
}, 0);
} //!isplaying
});

thumbnail.addEventListener("dragend", () => {
thumbnail.style.display = "block"; // Restaurar el elemento
setActiveList("layer");
});

// Manejo de eventos de soltar
thumbnail.addEventListener("dragover", (event) => {
event.preventDefault(); // Permitir el drop
});

thumbnail.addEventListener("drop", (event) => {
event.preventDefault(); // Prevenir el comportamiento por defecto
const draggedIndex = event.dataTransfer.getData("text/plain"); // Obtener el índice arrastrado
const draggedLayer = currentSprite.layers[draggedIndex]; // Obtener la capa arrastrada

// Intercambiar posiciones
if (draggedIndex !== index) {
currentSprite.layers.splice(draggedIndex, 1); // Eliminar la capa arrastrada
currentSprite.layers.splice(index, 0, draggedLayer); // Insertar en la nueva posición
currentSprite.currentLayerIndex = index; // Actualizar el índice actual

updateLayerBar(); // Volver a actualizar la barra de capas
updateCurrentLayer(); // Actualizar la vista de la capa actual
}
});

thumbnail.addEventListener("click", () => {
if (!isPlaying && !is3DActive) {
currentSprite.currentLayerIndex = index;

updateSpriteBar();
updateCurrentSprite();
updateCurrentLayer();
updateLayerBar();
}
});

const thumbCanvas = document.createElement("canvas");
thumbCanvas.width = 500;
thumbCanvas.height = 500;
const thumbCtx = thumbCanvas.getContext("2d");
const scale = 500 / currentSprite.gridSize;

layer.cells.forEach((cell, i) => {
const x = (i % currentSprite.gridSize) * scale;
const y = Math.floor(i / currentSprite.gridSize) * scale;

if (cell.textured && cell.texture) {
// Si la celda tiene textura, dibuja la textura en la miniatura
const texturaData = getTexturaById(cell.texture);
if (texturaData && texturaData.gifDataUrl) {
const img = new Image();
img.onload = () => {
thumbCtx.drawImage(img, x, y, scale, scale);
};
img.src = texturaData.gifDataUrl;
} else {
// Si no se encuentra la textura, dibuja un patrón o color de respaldo
thumbCtx.fillStyle = "#ccc"; // Color de respaldo
thumbCtx.fillRect(x, y, scale, scale);
}
} else if (cell.painted) {
// Si la celda está pintada con un color, dibuja el color
thumbCtx.fillStyle = cell.color;
thumbCtx.fillRect(x, y, scale, scale);
}
});

thumbnail.appendChild(thumbCanvas);
layerBar.appendChild(thumbnail);
});
}


// ============================
// === Añadir Nueva Capa ===
// ============================
function addLayer() {
const currentSprite = sprites[currentSpriteIndex];

let newCells = Array(currentSprite.gridSize * currentSprite.gridSize)
.fill(null)
.map(() => ({
painted: false,
color: gridBackgroundColor,
textured:false,
texture:null
}));

currentSprite.layers.push({ size: currentSprite.gridSize, cells: newCells });
currentSprite.currentLayerIndex = currentSprite.layers.length - 1;
updateLayerBar();
updateCurrentLayer();
}


// ============================
function updateCurrentLayer() {
grid.innerHTML = "";
const currentSprite = sprites[currentSpriteIndex];
const currentLayer = currentSprite.layers[currentSprite.currentLayerIndex];

createGrid(currentLayer.size, currentLayer.cells, true,grid);
}

// ============================

function saveCurrentLayer() {

if (isPreviewMode) return;

const currentSprite = sprites[currentSpriteIndex];
const currentLayer = currentSprite.layers[currentSprite.currentLayerIndex];
const cells = Array.from(grid.children).map(cell => ({
painted: cell.classList.contains("active"),
color: cell.style.backgroundColor || gridBackgroundColor,
textured: cell.dataset.textured === 'true',
texture: cell.dataset.texture || null
}));
currentLayer.cells = cells;
updateLayerBar();
updateSpriteBar();
}

// ============================

function deleteLayer() {
const currentSprite = sprites[currentSpriteIndex];
if (currentSprite.layers.length > 1) {
// Se guarda solo si estamos en modo edición
if (!isPreviewMode) saveCurrentLayer();
currentSprite.layers.splice(currentSprite.currentLayerIndex, 1);
currentSprite.currentLayerIndex = Math.min(
currentSprite.currentLayerIndex,
currentSprite.layers.length - 1
);
updateLayerBar();
updateCurrentLayer();
} else {
mostrarMensaje("No puedes eliminar la única capa.");
}
}

// ============================
// === Copiar y Pegar Capa ===
// ============================
function copyLayer() {
const currentSprite = sprites[currentSpriteIndex];
copiedLayer = JSON.parse(
JSON.stringify(currentSprite.layers[currentSprite.currentLayerIndex])
);
}

function pasteLayer() {
if (copiedLayer) {
const currentSprite = sprites[currentSpriteIndex];
currentSprite.layers.push(JSON.parse(JSON.stringify(copiedLayer)));
currentSprite.currentLayerIndex = currentSprite.layers.length - 1;
updateLayerBar();
updateCurrentLayer();
}
}

// ============================

function mergeLayers(sprite) {
let mergedCells = Array(sprite.gridSize * sprite.gridSize)
.fill(null)
.map(() => ({
painted: false,
color: gridBackgroundColor,
textured: false,
texture: null
}));

// Iterar sobre las capas en orden inverso
for (let i = sprite.layers.length - 1; i >= 0; i--) {
const layer = sprite.layers[i];
layer.cells.forEach((cell, j) => {
if (cell.painted || cell.textured) {
mergedCells[j] = { ...cell };
}
});
}
return mergedCells;
}


// ============================
// === TOGGLE 3D ===
// ============================
let outputFPS = document.getElementById("outputFPS");
outputFPS.style.display = "none !important";

// Función para alternar entre 2D y 3D
function toggleView() {


//activarTouchMove(); 
if(isPlaying)
{
togglePlayPause();
}
 currentSpriteIndex=0;

startThreeD();

let main2d = document.getElementById("main2d");
let main3d = document.getElementById("main3d");
let secondaryBlock = document.getElementById("secondaryBlock");


const fadeDuration = 1000; 

if (main3d.style.display === "none") {

// Fade out de main2d
main2d.classList.remove("fade-in");
main2d.classList.add("fade-out");

// Fade out de secondaryBlock
secondaryBlock.classList.remove("fade-in");
secondaryBlock.classList.add("fade-out");

setTimeout(() => {
main2d.style.display = "none";
main2d.classList.remove("fade-out");

secondaryBlock.style.display = "none";
secondaryBlock.classList.remove("fade-out");


// Fade in de main3d
main3d.style.display = "flex";
main3d.style.aspectRatio = "1";
main3d.classList.add("fade-in");


setTimeout(() => {
main3d.classList.remove("fade-in");
}, fadeDuration);

is3DActive = true;

}, fadeDuration);
} else {
// TRANSICIÓN: 3D -> 2D

// Fade out de main3d
main3d.classList.remove("fade-in");
main3d.classList.add("fade-out");


setTimeout(() => {
main3d.style.display = "none";
main3d.classList.remove("fade-out");



// Fade in de main2d
main2d.style.display = "flex";
main2d.style.aspectRatio = "1";
main2d.classList.add("fade-in");

// Fade in de secondaryBlock
secondaryBlock.style.display = "flex";
secondaryBlock.classList.add("fade-in");

setTimeout(() => {
main2d.classList.remove("fade-in");
secondaryBlock.classList.remove("fade-in");
}, fadeDuration);

// Acciones adicionales al cambiar de vista

is3DActive = false;
sprites3d = [];
camera.rotation = { x: 0, y: 0, z: 0 };
currentLayerIndex = 0;
currentSpriteIndex = 0;
currentSprite = [];
currentLayer = [];
stopThreeD();
updateSpriteBar();
updateLayerBar();
updateCurrentLayer();
}, fadeDuration);
}
}

//============================

// Asignar el evento al botón
document.getElementById("toggle3D").addEventListener("click", toggleView);



// ============================

function updateCurrentSprite() {
grid.innerHTML = "";
const currentSprite = sprites[currentSpriteIndex];

const mergedCells = mergeLayers(currentSprite);

createGrid(currentSprite.gridSize, mergedCells, false,grid);
}

// ============================
function addSprite() {
if (!isPreviewMode) {
// Puedes agregar aquí lógica adicional si es necesario cuando no está en modo previsualización
}
let size = gridSize;
let newCells = Array(size * size)
.fill(null)
.map(() => ({
painted: false,
color: gridBackgroundColor,
textured: false,
texture: null // Inicializar la propiedad texture
}));
sprites.push({
gridSize: size,
currentLayerIndex: 0,
layers: [{ size: size, cells: newCells }],
textures: [] // Inicializar un array para almacenar las texturas del sprite
});
currentSpriteIndex = sprites.length - 1;
isPreviewMode = false; // Al crear un sprite, se entra en modo edición.
is3DActive = false;
updateSpriteBar();
updateLayerBar();
updateCurrentLayer();
}

//============================

function saveCurrentSprite() {
const currentSprite = sprites[currentSpriteIndex];
const size = currentSprite.gridSize;
const cells = Array.from(grid.children).map(cell => ({
painted: cell.classList.contains("active"),
color: cell.style.backgroundColor || gridBackgroundColor,
textured: cell.dataset.textured === 'true', // Leer el atributo data-textured
texture: cell.dataset.texture || null// Leer el atributo data-texture
}));
currentSprite.layers[currentSprite.currentLayerIndex].cells = cells;
currentSprite.layers[currentSprite.currentLayerIndex].size = size;
updateLayerBar();
updateSpriteBar();
}

//============================

function updateSpriteBar() {
if (is3DActive || isPlaying) return; // Bloquea cambios si está en 3D o en reproducción

spriteBar.innerHTML = "";
spriteBar.classList.add("active");
layerBar.classList.remove("active");

let infoBtn = document.createElement("div");

infoBtn.textContent = "i";
infoBtn.classList.add("add-sprite");
infoBtn.id = "infoBtn";
spriteBar.appendChild(infoBtn);

const addSpriteButton = document.createElement("div");
addSpriteButton.classList.add("add-sprite");
addSpriteButton.textContent = "+";
addSpriteButton.addEventListener("click", () => {
if (!isPlaying) addSprite();
});


spriteBar.appendChild(addSpriteButton);


sprites.forEach((sprite, index) => {
const thumbnail = document.createElement("div");
thumbnail.classList.add("sprite-thumbnail");
thumbnail.setAttribute("draggable", "true"); // Hacer el thumbnail arrastrable

if (index === currentSpriteIndex) {
thumbnail.classList.add("selected");
}

// Manejo de eventos de arrastrar
thumbnail.addEventListener("dragstart", (event) => {
if (!isPlaying) {
event.dataTransfer.setData("text/plain", index); // Guardar el índice del sprite
thumbnail.style.opacity = "0.9"; // Aplicar opacidad mientras se arrastra


setTimeout(() => {
//thumbnail.style.display = "none"; // Ocultar el elemento arrastrado
}, 0);
} //!isplaying
});

thumbnail.addEventListener("dragend", () => {
thumbnail.style.display = "block"; // Restaurar el elemento
setActiveList("layer");
});

// Manejo de eventos de soltar
thumbnail.addEventListener("dragover", (event) => {
event.preventDefault(); // Permitir el drop
});

thumbnail.addEventListener("drop", (event) => {
event.preventDefault(); // Prevenir el comportamiento por defecto
const draggedIndex = event.dataTransfer.getData("text/plain"); // Obtener el índice arrastrado
const draggedSprite = sprites[draggedIndex]; // Obtener el sprite arrastrado

// Intercambiar posiciones
if (draggedIndex !== index) {
sprites.splice(draggedIndex, 1); // Eliminar el sprite arrastrado
sprites.splice(index, 0, draggedSprite); // Insertar en la nueva posición
currentSpriteIndex = index; // Actualizar el índice actual

updateSpriteBar(); // Volver a actualizar la barra de sprites
updateCurrentSprite(); // Actualizar la vista del sprite actual
}
});

thumbnail.addEventListener("click", () => {
if (!isPlaying && !is3DActive) {
currentSpriteIndex = index;
isPreviewMode = true;
updateSpriteBar();
updateCurrentSprite();
updateCurrentLayer();
updateLayerBar();
}
});

const thumbCanvas = document.createElement("canvas");
thumbCanvas.width = 500;
thumbCanvas.height = 500;
const thumbCtx = thumbCanvas.getContext("2d");
const scale = 500 / sprite.gridSize;
let mergedCells = mergeLayers(sprite);

mergedCells.forEach((cell, i) => {
const x = (i % sprite.gridSize) * scale;
const y = Math.floor(i / sprite.gridSize) * scale;

if (cell.textured && cell.texture) {
// Si la celda tiene textura, dibuja la textura en la miniatura
const texturaData = getTexturaById(cell.texture);
if (texturaData && texturaData.gifDataUrl) {
const img = new Image();
img.onload = () => {
thumbCtx.drawImage(img, x, y, scale, scale);
};
img.src = texturaData.gifDataUrl;
} else {
// Si no se encuentra la textura, dibuja un patrón o color de respaldo
thumbCtx.fillStyle = "#ccc"; // Color de respaldo
thumbCtx.fillRect(x, y, scale, scale);
}
} else if (cell.painted) {
// Si la celda está pintada con un color, dibuja el color
thumbCtx.fillStyle = cell.color;
thumbCtx.fillRect(x, y, scale, scale);
}
});

thumbnail.appendChild(thumbCanvas);
spriteBar.appendChild(thumbnail);
});
}

//============================


let currentSpeed = 500; // Velocidad inicial en ms
let minSpeed = 100; // Límite mínimo
let animSpeed = 1000; // Límite máximo
let step = 100; // Incremento/decremento
let speedIndex=4;

// Inicializamos animationSpeed con currentSpeed
let animationSpeed = currentSpeed;

function updateSpeedDisplay() {
speedDisplay.textContent = speedIndex;
}

increaseSpeedButton.addEventListener("click", () => {

// Actualiza speedIndex: si llega a 10 se reinicia a 1
speedIndex = (speedIndex < 10) ? speedIndex + 1 : 1;

// Asigna animationSpeed según el valor fijo determinado para cada índice
switch (speedIndex) {
case 1:
animationSpeed = 1000;
break;
case 2:
animationSpeed = 900;
break;
case 3:
animationSpeed = 800;
break;
case 4:
animationSpeed = 700;
break;
case 5:
animationSpeed = 600;
break;
case 6:
animationSpeed = 500;
break;
case 7:
animationSpeed = 400;
break;
case 8:
animationSpeed = 300;
break;
case 9:
animationSpeed = 200;
break;
case 10:
animationSpeed = 100;
break;
default:
animationSpeed = 1000;
}
if (isPlaying) {
clearInterval(animationInterval);
startAnimation();
}
updateSpeedDisplay();
});
// ============================
// === Reproducir o Pausar ===
// ============================

const viewModePanel = document.getElementById("viewModePanel");

function togglePlayPause(){


if (isPlaying) {
clearInterval(animationInterval);
playPauseButton.textContent = "▶️";
playPause3DBtn.textContent = "▶️";

playPauseButton.style.backgroundColor = "";
playPauseButton.style.border = "";

isPlaying=false;
/*
currentSpriteIndex=0;
updateSpriteBar();
updateLayerBar();
updateCurrentLayer();
updateCurrentSprite();

setActiveList("layer");
*/

if(!is3DActive)
{
/*
viewModePanel.innerHTML = "";

viewModePanel.style.display="none";
grid.style.display="grid";
*/
currentSpriteIndex=0;
currentLayerIndex=0;


viewSize=9;

switch (gridSize) {
case 9:
viewSize = 9;
break;
default:
viewSize = 15;
break;
}
setActiveList("layer");
updateCurrentLayer();
}


} else {


playPauseButton.style.backgroundColor = "rgba(50, 200, 50, 0.7)";
playPauseButton.style.border = "2px solid red";

playPauseButton.textContent = "⏸️";
playPause3DBtn.textContent = "⏸️";
isPlaying = true;

if (is3DActive) {
startAnimation();
}
else 
{
/*
viewModePanel.style.display="block";
grid.style.display="none";

updateViewModePanel();
*/
viewSize=gridSize;
startAnimation();




}



setActiveList("sprite");
}




}

// ==========================
// === Animar Sprites ===
// ==========================
function startAnimation() {

clearInterval(animationInterval);
animationInterval = setInterval(() => {

currentSpriteIndex = (currentSpriteIndex + 1) % sprites.length;

if(!is3DActive)
{

//updateViewModePanel();

updateCurrentSprite();

}

}, animationSpeed);


}

// ==========================
// ==Update ViewModePanel===
// ==========================

function updateViewModePanel() {

viewModePanel.innerHTML = "";
let currentSprite = sprites[currentSpriteIndex];

let mergedCells = mergeLayers(currentSprite);


createGrid(currentSprite.gridSize, mergedCells, false, viewModePanel);
}





// ============================
// === Inicialización del Proyecto ===
// ============================
function inicializar(gridSizeValue) {

if (buttonControls) {
buttonControls.scrollLeft = 0;
}

switch (gridSizeValue) {
case 9:
viewSize = 9;
break;
default:
viewSize = 15;
break;
}

gridSize = gridSizeValue;
sprites.push({
gridSize: gridSize,
currentLayerIndex: 0,
layers: [
{
size: gridSize,
cells: Array(gridSize * gridSize)
.fill(null)
.map(() => ({
painted: false,
color: gridBackgroundColor,
})),
},
],
});


updateCurrentSprite();
updateSpriteBar();
updateLayerBar();
layerBar.style.display= "flex";
currentSpriteIndex = 0;
currentLayerIndex=0;
isPreviewMode = false;
is3DActive = false;
isPlaying=false;

setActiveList("layer");
updateCurrentLayer();
updateLayerBar();


 



//toggleCapas();


}


// ==========================
// === ACTIVE LIST ===
// ==========================

spriteBar.addEventListener("click", () => {
setActiveList("sprite");
});

layerBar.addEventListener("click", () => {
setActiveList("layer");
});


function setActiveList(list) {
activeList = list;

if (list === "sprite") {
spriteBar.classList.add("active");
layerBar.classList.remove("active");

// Eliminar la clase 'selected' de las capas
const layerThumbnails = document.querySelectorAll(".layer-thumbnail.selected");
layerThumbnails.forEach(thumbnail => thumbnail.classList.remove("selected"));


} else if (list === "layer") {
layerBar.classList.add("active");
spriteBar.classList.remove("active");


// Eliminar la clase 'selected' de los sprites

const spriteThumbnails = document.querySelectorAll(".sprite-thumbnail.selected");
spriteThumbnails.forEach(thumbnail => thumbnail.classList.remove("selected"));
updateCurrentLayer();
updateLayerBar();

} else {
spriteBar.classList.remove("active");
layerBar.classList.remove("active");

// Eliminar la clase 'selected' de ambos (sprites y capas)
const selectedThumbnails = document.querySelectorAll(".sprite-thumbnail.selected, .layer-thumbnail.selected");
selectedThumbnails.forEach(thumbnail => thumbnail.classList.remove("selected"));
}
}

// ============================
// === DELETE LOGIC ===
// ============================
/*
deleteButton.addEventListener("click", () => {
if (!isPlaying) {
if (activeList === "sprite") {
if (confirm("¿Está seguro de querer eliminar el cuadro seleccionado?")) {
deleteSprite();
}
} else if (activeList === "layer") {
if (confirm("¿Está seguro de querer eliminar la capa seleccionada?")) {
deleteLayer();
}
} else {
mostrarMensaje("No hay nada seleccionado para borrar.");
}
}
});
*/

// Variable para almacenar la función de eliminación a ejecutar
let eliminarCallback = null;

// Función para abrir el modal de eliminación con el mensaje deseado y asignar la acción
function openEliminarModal(message, callback) {
eliminarCallback = callback;
document.getElementById('mensajeEliminar').innerText = message;
document.getElementById('cuadroEliminar').style.display = 'flex';
}

// Reemplazamos el confirm nativo en el evento del botón de borrar
deleteButton.addEventListener("click", () => {
if (!isPlaying) {
if (activeList === "sprite") {
openEliminarModal("¿Está seguro de querer eliminar el cuadro seleccionado?", deleteSprite);
} else if (activeList === "layer") {
openEliminarModal("¿Está seguro de querer eliminar la capa seleccionada?", deleteLayer);
} else {
mostrarMensaje("No hay nada seleccionado para borrar.");
}
}
});

// Al confirmar la eliminación se ejecuta la función almacenada
document.getElementById('confirmarEliminarBtn').onclick = () => {
if (eliminarCallback) {
eliminarCallback();
}
document.getElementById('cuadroEliminar').style.display = 'none';
eliminarCallback = null;
};

// Al cancelar se cierra el modal y se resetea la función
document.getElementById('cancelarEliminarBtn').onclick = () => {
document.getElementById('cuadroEliminar').style.display = 'none';
eliminarCallback = null;
};

// También se puede cerrar el modal haciendo clic en la "X"
document.getElementById('cerrarCuadroEliminar').onclick = () => {
document.getElementById('cuadroEliminar').style.display = 'none';
eliminarCallback = null;
};

// ============================
// === Eliminar Sprite ===
// ============================
function deleteSprite() {

if (sprites.length > 1) {
// Solo se guarda si estamos en modo edición.
if (!isPreviewMode) saveCurrentLayer();

// Eliminamos el sprite en el índice actual.
sprites.splice(currentSpriteIndex, 1);

// Aseguramos que currentSpriteIndex no sea mayor que el índice más alto disponible.
if (currentSpriteIndex >= sprites.length) {
currentSpriteIndex = sprites.length - 1;
}

// Actualizamos las vistas de sprites y capas.
updateSpriteBar();
updateLayerBar();

// Si estamos en modo previsualización, mostramos el sprite fusionado (no editable).
if (isPreviewMode) {
updateCurrentSprite();
} else {
updateCurrentLayer();
}

// Si estábamos jugando, reiniciamos la animación.
if (isPlaying) {
clearInterval(animationInterval);
startAnimation();
}
} else {
mostrarMensaje("No puedes eliminar el único sprite.");
}
}



// ============================
// === DUPLICATE LOGIC ===
// ============================

/*
document.getElementById("duplicate").addEventListener("click", (event) => {
event.stopPropagation();

if (!isPlaying) {
if (activeList === "sprite") {
if (confirm("¿Seguro que quieres duplicar el cuadro?")) {
duplicateSprite();
}
} else if (activeList === "layer") {
const currentSprite = sprites[currentSpriteIndex];
if (currentSprite.layers.length < 10) {
if (confirm("¿Seguro que quieres duplicar la capa?")) {
duplicateLayer();
}
} else {
mostrarMensaje("No se pueden agregar más de 10 capas.");
}
} else {
mostrarMensaje("No hay nada seleccionado para duplicar.");
}
}
});
*/

// Variable para almacenar la función de duplicado a ejecutar
let duplicateCallback = null;

// Función para abrir el modal de duplicado con un mensaje y callback específico
function openDuplicateModal(message, callback) {
duplicateCallback = callback;
document.getElementById('duplicateModalMessage').innerText = message;
document.getElementById('confirmDuplicateModal').style.display = 'flex';
}

// Listener para el botón "duplicate"
document.getElementById("duplicate").addEventListener("click", (event) => {
event.stopPropagation();

if (!isPlaying) {
if (activeList === "sprite") {
// Abre el modal para duplicar el cuadro
openDuplicateModal("¿Seguro que quieres duplicar el cuadro?", duplicateSprite);
} else if (activeList === "layer") {
const currentSprite = sprites[currentSpriteIndex];
if (currentSprite.layers.length < 10) {
// Abre el modal para duplicar la capa
openDuplicateModal("¿Seguro que quieres duplicar la capa?", duplicateLayer);
} else {
mostrarMensaje("No se pueden agregar más de 10 capas.");
}
} else {
mostrarMensaje("No hay nada seleccionado para duplicar.");
}
}
});

// Evento para confirmar duplicado
document.getElementById('confirmDuplicateBtn').onclick = () => {
if (duplicateCallback) {
duplicateCallback();
}
document.getElementById('confirmDuplicateModal').style.display = 'none';
duplicateCallback = null;
};

// Evento para cancelar duplicado
document.getElementById('cancelDuplicateBtn').onclick = () => {
document.getElementById('confirmDuplicateModal').style.display = 'none';
duplicateCallback = null;
};

// También se puede cerrar el modal haciendo clic en la "X"
document.getElementById('closeDuplicateModal').onclick = () => {
document.getElementById('confirmDuplicateModal').style.display = 'none';
duplicateCallback = null;
};

// ============================
// === DUPLICAR SPRITE ===
// ============================

function duplicateSprite() {
if (sprites.length === 0) return;



// Clonar el sprite correctamente sin referencias compartidas
let newSprite = JSON.parse(JSON.stringify(sprites[currentSpriteIndex]));

// Crear un nuevo objeto para evitar referencias compartidas
newSprite = {
gridSize: newSprite.gridSize,
currentLayerIndex: 0, // Restablecer la selección de la capa
layers: newSprite.layers.map(layer => ({
size: layer.size,
cells: layer.cells.map(cell => ({ ...cell })) // Clonando celdas de manera segura
}))
};

// Agregar el nuevo sprite al final
sprites.push(newSprite);

// Seleccionar la nueva copia
currentSpriteIndex = sprites.length - 1;

updateSpriteBar();
updateLayerBar();
updateCurrentLayer();
updateCurrentSprite();
}

// ============================
// === DUPLICAR CAPA ===
// ============================

function duplicateLayer() {
if (sprites.length === 0) return;

const currentSprite = sprites[currentSpriteIndex];
if (currentSprite.layers.length === 0) return;

// Clonar la capa actual correctamente evitando referencias compartidas
let newLayer = JSON.parse(JSON.stringify(currentSprite.layers[currentSprite.currentLayerIndex]));

newLayer = {
size: newLayer.size,
cells: newLayer.cells.map(cell => ({ ...cell })) // Clonando celdas individualmente
};

// Agregar la nueva capa al final de la lista de capas
currentSprite.layers.push(newLayer);

// Seleccionar la nueva copia de la capa
currentSprite.currentLayerIndex = currentSprite.layers.length - 1;

updateLayerBar();
updateSpriteBar();
updateCurrentSprite();
updateCurrentLayer();
}

// Función para oscurecer o aclarar un color en formato hexadecimal.
// percent: valor negativo para oscurecer, positivo para aclarar.
function shadeColor(color, percent) {
let num = parseInt(color.slice(1), 16),
amt = Math.round(2.55 * percent),
R = (num >> 16) + amt,
G = (num >> 8 & 0x00FF) + amt,
B = (num & 0x0000FF) + amt;
return "#" + (
0x1000000 +
(R < 255 ? (R < 0 ? 0 : R) : 255) * 0x10000 +
(G < 255 ? (G < 0 ? 0 : G) : 255) * 0x100 +
(B < 255 ? (B < 0 ? 0 : B) : 255)
).toString(16).slice(1);
}

// Array de colores base (10 colores)
// Función para convertir un color HEX a HSL
function hexToHSL(hex) {
let r = 0, g = 0, b = 0;
if (hex.length === 4) {
r = "0x" + hex[1] + hex[1];
g = "0x" + hex[2] + hex[2];
b = "0x" + hex[3] + hex[3];
} else if (hex.length === 7) {
r = "0x" + hex[1] + hex[2];
g = "0x" + hex[3] + hex[4];
b = "0x" + hex[5] + hex[6];
}
r /= 255;
g /= 255;
b /= 255;

const cmin = Math.min(r, g, b);
const cmax = Math.max(r, g, b);
const delta = cmax - cmin;
let h = 0;
let s = 0;
let l = (cmax + cmin) / 2;

if (delta !== 0) {
s = delta / (1 - Math.abs(2 * l - 1));
if (cmax === r) {
h = ((g - b) / delta) % 6;
} else if (cmax === g) {
h = (b - r) / delta + 2;
} else {
h = (r - g) / delta + 4;
}
}
h = Math.round(h * 60);
if (h < 0) h += 360;
s = +(s * 100).toFixed(1);
l = +(l * 100).toFixed(1);
return { h, s, l };
}

// Función para convertir HSL a HEX
function hslToHex(h, s, l) {
s /= 100;
l /= 100;
const c = (1 - Math.abs(2 * l - 1)) * s;
const x = c * (1 - Math.abs((h / 60) % 2 - 1));
const m = l - c / 2;
let r = 0, g = 0, b = 0;

if (h >= 0 && h < 60) {
r = c; g = x; b = 0;
} else if (h >= 60 && h < 120) {
r = x; g = c; b = 0;
} else if (h >= 120 && h < 180) {
r = 0; g = c; b = x;
} else if (h >= 180 && h < 240) {
r = 0; g = x; b = c;
} else if (h >= 240 && h < 300) {
r = x; g = 0; b = c;
} else if (h >= 300 && h < 360) {
r = c; g = 0; b = x;
}

r = Math.round((r + m) * 255);
g = Math.round((g + m) * 255);
b = Math.round((b + m) * 255);

const toHex = (num) => {
const hex = num.toString(16);
return hex.length === 1 ? "0" + hex : hex;
};

return "#" + toHex(r) + toHex(g) + toHex(b);
}

// Función para convertir un string RGB (ej. "rgb(255, 0, 0)") a HEX
function rgbToHex(rgb) {
const result = rgb.match(/\d+/g);
if (!result) return rgb;
return (
"#" +
result
.map((x) => parseInt(x).toString(16).padStart(2, "0"))
.join("")
);
}

/*
Función para generar la tonalidad modificando la luminosidad.
En lugar de sumar directamente el porcentaje, se mapea el rango de -50 a 50 a un rango fijo de luminosidad (20% a 80%).
*/
function shadeColor(hex, percent) {
const hsl = hexToHSL(hex);
// Mapeamos percent de [-50, 50] a un valor de luminosidad entre 20 y 80
const newL = ((percent + 50) / 100) * 60 + 20;
return hslToHex(hsl.h, hsl.s, newL);
}

// Colores base
const baseColors = [
"#FF0000", // Rojo
"#00FF00", // Verde
"#0000FF", // Azul
"#FFFF00", // Amarillo
"#FF00FF", // Magenta
"#00FFFF", // Cian
"#FFA500", // Naranja
"#A52A2A", // Marrón
"#C0C0C0", // Plateado
"#8B4513", // Sienna
"#FFD700" // Dorado
];

// Porcentajes para generar las tonalidades (de más oscuro a más claro)
const variationPercents = [-50, -40, -30, -20, -10, 0, 10, 20, 30, 40, 50];

// Se obtiene el elemento donde se agregarán los colores
const colorBar = document.getElementById("colorBar");

// Verificamos que exista el contenedor
if (!colorBar) {
console.error("No se encontró el elemento con id 'colorBar'");
} else {
let selectedElement = null;

// Función que se ejecuta al seleccionar un color
function selectColor(element, color) {
if (selectedElement) {
selectedElement.classList.remove("selected");
// Revertir estilos del elemento previamente seleccionado
selectedElement.style.transform = "";
selectedElement.style.border = "none";
}
element.classList.add("selected");
selectedElement = element;
// Aquí puedes agregar acciones adicionales, por ejemplo asignar el color a un input.
// Aplicar estilos al elemento seleccionado
element.style.transform = "scale(1.3)"; // Aumenta un poco el tamaño
element.style.border = "4px solid black"; // Borde negro más marcado
}


// Estilos básicos para cada elemento de color
let colorItemStyle = {
width: "10vw",
height: "10vw",
border: "2px solid #ccc",
borderRadius: "4px",
cursor: "pointer",
transition: "transform 0.2s, border-color 0.2s",
margin: "2px"
};

// Generar los elementos de color y agregarlos a colorBar
baseColors.forEach((baseColor) => {
variationPercents.forEach((percent) => {
const tone = shadeColor(baseColor, percent);
const colorItem = document.createElement("div");

colorItem.classList.add("colorItemStyle");
// Asignar estilos
//Object.assign(colorItem.style, colorItemStyle);
colorItem.style.backgroundColor = tone;
colorItem.setAttribute("data-color", tone);

// Eventos para hover y click
colorItem.addEventListener("mouseover", function () {
this.style.transform = "scale(1.1)";
});
colorItem.addEventListener("mouseout", function () {
this.style.transform = "";
});
colorItem.addEventListener("click", () => {
selectColor(colorItem, tone);
// Suponiendo que "colorSelect" es un input existente en tu HTML para mostrar el color seleccionado
if (typeof colorSelect !== "undefined") {
colorSelect.value = rgbToHex(colorItem.style.backgroundColor);
}

currentTexture=null;

});

// Agregar el elemento al contenedor colorBar
colorBar.appendChild(colorItem);


});
});
}

function toggleCapas() {

let capasBtn = document.getElementById("capasBtn");


if (layerBar.classList.contains("fade-in")) {



layerBar.classList.remove("fade-in");
 layerBar.classList.add("fade-out");
 
 layerBar.style.pointerEvents="none";




capasBtn.style.backgroundColor = ""; // Restablece el color de fondo del botón
capasBtn.style.border="";


} else {

// Si la barra de capas está oculta, muéstrala y cambia el estilo del botón

layerBar.classList.remove("fade-out");
layerBar.classList.add("fade-in");
layerBar.style.pointerEvents="auto";

capasBtn.style.backgroundColor = "rgba(50, 200, 50, 0.7)";
capasBtn.style.border="2px solid red";
}
}

async function downloadAllSprites() {
if (sprites.length === 0) {
console.error("No hay sprites para agregar al ZIP.");
return null;
}

disableUserInteraction(); // Desactivar interacción del usuario

const spritesFolder = {}; // Objeto para almacenar los archivos PNG

for (let index = 0; index < sprites.length; index++) {
const sprite = sprites[index];
const canvas = document.createElement("canvas");
const ctx = canvas.getContext("2d");
canvas.width = 512;
canvas.height = 512;
const scale = 512 / sprite.gridSize;

// Fusionar capas en un solo sprite (ahora considera texturas)
const mergedCells = mergeLayers(sprite);

for (let i = 0; i < mergedCells.length; i++) {
const cell = mergedCells[i];
const x = (i % sprite.gridSize) * scale;
const y = Math.floor(i / sprite.gridSize) * scale;

if (cell.textured && cell.texture) {
const texturaData = getTexturaById(cell.texture);
if (texturaData && texturaData.gifDataUrl) {
// Dibujar la textura en el canvas
const img = new Image();
await new Promise((resolve, reject) => {
img.onload = () => {
ctx.drawImage(img, x, y, scale, scale);
resolve();
};
img.onerror = reject;
img.src = texturaData.gifDataUrl;
});
}
} else if (cell.painted) {
ctx.fillStyle = cell.color;
ctx.fillRect(x, y, scale, scale);
}
}

const dataURL = canvas.toDataURL("image/webp");
const blob = await (await fetch(dataURL)).blob();
spritesFolder[`frame_${index + 1}.webp`] = blob; // Guardar cada imagen con su nombre
}

setTimeout(() => {
enableUserInteraction(); // Reactivar interacción del usuario
}, 5000); // Ajusta el tiempo según sea necesario

return spritesFolder; // Devuelve el objeto con los archivos PNG
}



function updateGrid() {
// Se asume que 'grid' es el elemento contenedor principal y 'viewSize' es la variable global con el nuevo valor.
// Se obtiene el contenedor de la grilla, que es el primer hijo de 'grid'
const gridContainer = grid.firstElementChild;
if (!gridContainer) return; // Si no existe, no hay nada que actualizar

// Calcular el nuevo tamaño de cada celda en función del ancho actual de 'grid' y el 'viewSize'
const cellSize = grid.offsetWidth / viewSize;

// Determinar el tamaño de la grilla: asumimos que es cuadrada, por lo que se calcula la raíz cuadrada del número de celdas.
const numCells = gridContainer.children.length;
const size = Math.sqrt(numCells);

// Actualizar las dimensiones del contenedor de la grilla
gridContainer.style.width = `${size * cellSize}px`;
gridContainer.style.height = `${size * cellSize}px`;

// Recorrer cada celda y actualizar su tamaño y posición
for (let i = 0; i < numCells; i++) {
const cell = gridContainer.children[i];
cell.style.width = `${cellSize}px`;
cell.style.height = `${cellSize}px`;
cell.style.left = `${(i % size) * cellSize}px`;
cell.style.top = `${Math.floor(i / size) * cellSize}px`;
}

}

const toggleCellSize = document.getElementById("toggleCellSize");

function toggleViewSize() {
 
 if (isPlaying)
{
togglePlayPause();
}

 if(!isPlaying)
 {
if (viewSize == 9 && gridSize>9)
{
viewSize = 15;


updateGrid();
}
else {
viewSize = 9;

updateGrid();
}

 }
}


function togglePanelTexturas() {
if (panelTexturas.style.display === "none")
{
panelTexturas.style.display = "block";

}
else {
panelTexturas.style.display = "none";

}
}

toggleTexturas.onclick = () => {

togglePanelTexturas();
};


const texturaBtnes = document.getElementsByClassName('texturaBtn');

Array.from(texturaBtnes).forEach(boton => {
boton.addEventListener('click', () => {

togglePanelTexturas();

});
});