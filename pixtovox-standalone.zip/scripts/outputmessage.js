function mostrarMensaje(mensaje,outputElement, duracion=2500) {
const output = document.getElementById(outputElement);
//output.innerHTML = `<p>${mensaje}</p>`;
output.style.display='flex';
output.textContent=mensaje;


// Si el elemento tiene la clase 'fade-out', elimina las clases y reinicia la animación
if (output.classList.contains('fade-out')) {
output.classList.remove('fade-out', 'fade-in');
}

// Agregar la clase 'fade-in' para que se ejecute la animación de entrada
output.classList.add('fade-in');

setTimeout(() => {
output.classList.add('fade-out');
}, duracion);

output.addEventListener('transitionend', () => {
if (output.classList.contains('fade-out')) {
output.style.display = 'none';
output.classList.remove('fade-out', 'fade-in'); // Elimina ambas clases al final
}
}, { once: true });
}
