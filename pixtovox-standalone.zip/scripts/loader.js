meshes = [];

sprites3d=[];

let tileSize = 9;

let tileScale = 40;

//cell view size 
let viewSize=9;

let is3DActive = false;

let skyboxTextureOn=false;

baseResolution=1000;
let resolution = 1000;

distance=300000;
//------------------------------//

let canvas2D = document.getElementById("canvas2D");

canvas2D.width = resolution;
canvas2D.height = resolution;

//-----------------------------//
canvas=canvas2D;

//-----------------------------//


//LOADER v2
function loadObject2(file){
let request = new XMLHttpRequest();
let mesh= [];
request.open("GET", file, false);
 
request.onreadystatechange = function()
{

if (request.readyState === 4)
{
if (request.status === 200 || request.status == 0)
{

let obj=request.responseText;
let str=String(obj);

 let arr= str.split(/\n/);
 let vectors=[];
 
 //VECTORS
for(let i=0;i<arr.length;i++)
{

//vectors
if (arr[i].match(/^v\s/))
{
//erase
 let p= arr[i].replace("v ","");
 let s=p.replace("v ","");
 //change "," with "."
s= p.replace(/\,/gm,".");
//split into 3 coords
let v= s.split(/\s/);
//fill in vector coords in numbers
let c={x:(+v[0]),y:(+v[1]),z:(+v[2])};

//c.wx=roundToDecimals(c.wx,1);
//c.wy=roundToDecimals(c.wy,1);
//c.wz=roundToDecimals(c.wz,1);
c.wx=c.wx;
c.wy=c.wy;
c.wz=c.wz;

//add vectors
vectors.push(c);


}

}//VECTORS
 
 //TRIANGLES
 for(let i=0;i<arr.length;i++)
{
//triangles
if(arr[i].match(/^f/))
{
//clean
let clean= arr[i].replace("f ","");
//split
let split= clean.split(/\s/);

 // take the first value
let index1= +split[0].match(/\d+/m); 
let index2= +split[1].match(/\d+/m);
let index3= +split[2].match(/\d+/m);

let triangle=[];


triangle.push(vectors[index1-1],vectors[index2-1],vectors[index3-1]);

triangle.visible=true;

mesh.push(triangle);

}
}//TRIANGLES
}
}
}
request.send(null);

return mesh;
};// LOADER v2

//-----------------------------//


/*
//EJEMPLO DE INICIALIZACIÓN DE OBJ
let north =loadObject2("obj/north.obj");
north.scale=30;
north.position={x:0,y:50,z:100};
north.name= "north";
north.baseColor={r:150,g:150,b:0};
north.rotation={x:0,y:Math.PI,z:0};

*/

//-----------------------------//
/*
light = loadObject2(".../obj/rndCube.obj");
light.scale = 10000;
light.position = { x:24000, y: 24000, z:24000};
light.name = "light";
light.baseColor = { r: 255, g: 250, b: 0 };
light.rotation = { x: 0, y: 0, z: 0 };
light.forward={ x: 0, y: 0, z: 1 };

//-----------------------------//

let skybox = loadObject2("obj/sphere.obj");
skybox.scale = 200000;
skybox.position = { x: 0, y: 0, z: 0 };
skybox.name = "skybox";
skybox.baseColor = { r: 120, g: 150, b: 190 };
skybox.rotation = { x: 0, y: Math.PI, z: 0 };
skybox.texture="texturas/papel.webp";

*/
function activarPantallaCompleta() {
let elemento = document.documentElement; // O usa otro elemento específico como `document.getElementById("juego")`

if (elemento.requestFullscreen) {
elemento.requestFullscreen();
} else if (elemento.mozRequestFullScreen) { // Firefox
elemento.mozRequestFullScreen();
} else if (elemento.webkitRequestFullscreen) { // Chrome, Safari y Opera
elemento.webkitRequestFullscreen();
} else if (elemento.msRequestFullscreen) { // IE/Edge
elemento.msRequestFullscreen();
}
}



function togglePantallaCompleta() {

parent.togglePantallaCompleta();

}


document.addEventListener("DOMContentLoaded", () => {
document.documentElement.requestFullscreen();
});

/*
function toggleGl() {
if (webgl) {
canvas2D.style.display = "block";
canvas3D.style.display = "none";

canvas= canvas2D;
mostrarMensaje("WEBGL OFF","outputProject");
console.log("webgl off");
webgl = false;
} else {
canvas2D.style.display = "none";
canvas3D.style.display = "block";
canvas= canvas3D;
mostrarMensaje("WEBGL ON","outputProject");
console.log("webgl on");
webgl = true;
}

ctx2d = null;
ctxSkybox = null;
gl = null;

if (webgl)
{
gl = canvas.getContext("webgl", { antialias: true });
}
else
{
ctx2d = canvas.getContext("2d");
ctx2d.isSmoothEnable = true;

ctxSkybox = canvasSkybox.getContext("2d");
ctxSkybox.isSmoothEnable = true;
}

}
*/

function showSpinner() {
  const spinner = document.getElementById("spinner");
  if (spinner) {
    spinner.style.display = "block";
  }
}

function hideSpinner() {
  const spinner = document.getElementById("spinner");
  if (spinner) {
    spinner.style.display = "none";
  }
}

layerBar.classList.add("fade-in");


function togglePantallaCompleta() {
  if (!document.fullscreenElement) {
    document.documentElement.requestFullscreen();
  } else if (document.exitFullscreen) {
    document.exitFullscreen();
  }
  
  document.getElementById('menu').style.display = 'none';
}



function activarPantallaCompleta() {
  let elemento = document.documentElement; // O usa otro elemento específico como `document.getElementById("app")`
  
  if (elemento.requestFullscreen) {
    elemento.requestFullscreen();
  } else if (elemento.mozRequestFullScreen) { // Firefox
    elemento.mozRequestFullScreen();
  } else if (elemento.webkitRequestFullscreen) { // Chrome, Safari y Opera
    elemento.webkitRequestFullscreen();
  } else if (elemento.msRequestFullscreen) { // IE/Edge
    elemento.msRequestFullscreen();
  }
}
