//=============================
//=== Manejo de Base de Datos (JSON) ===
//=============================

// Inicializa la base de datos si no existe
function initDatabase() {
if (!localStorage.getItem('pixtovoxAssetProjects')) {
localStorage.setItem('pixtovoxAssetProjects', JSON.stringify([])); // Crea una lista vacía
}
}

// Obtener todos los proyectos
function getAllProjects() {
return new Promise((resolve) => {
const projects = JSON.parse(localStorage.getItem('pixtovoxAssetProjects'));
resolve(projects);
});
}

// Obtener proyecto por ID
function getProjectById(projectId) {
return new Promise((resolve) => {
const projects = JSON.parse(localStorage.getItem('pixtovoxAssetProjects'));
const project = projects.find((p) => p.id === projectId);
resolve(project);
});
}

function saveProject(project) {
  return new Promise((resolve) => {
    const projects = JSON.parse(localStorage.getItem("pixtovoxAssetProjects")) || [];
    const index = projects.findIndex((p) => p.id === project.id);

    if (index !== -1) {
      projects[index] = project; // Actualiza el proyecto existente
    } else {
      projects.push(project); // Agrega un nuevo proyecto
    }

    localStorage.setItem("pixtovoxAssetProjects", JSON.stringify(projects));
    resolve();
  });
}


// Eliminar un proyecto por ID
function deleteProject(projectId) {
return new Promise((resolve) => {
let projects = JSON.parse(localStorage.getItem('pixtovoxAssetProjects'));
projects = projects.filter((p) => p.id !== projectId);
localStorage.setItem('pixtovoxAssetProjects', JSON.stringify(projects));
resolve();
});
}



// Lista de archivos JSON en la carpeta /demos
const archivos = [
"tree.json",
"espada.json"
// Agrega aquí los nombres de tus archivos JSON
];

// Función para cargar proyectos desde los archivos JSON
async function cargarProyectosDesdeCarpeta() {
const proyectos = JSON.parse(localStorage.getItem("pixtovoxAssetProjects")) || [];
if (proyectos.length === 0) {
try {
const proyectosNuevos = [];

for (const archivo of archivos) {
const response = await fetch(`/demos/${archivo}`);
if (!response.ok) {
console.error(`Error al cargar ${archivo}: ${response.status} ${response.statusText}`);
continue; // Saltar este archivo si hay un error
}

const proyecto = await response.json();
proyectosNuevos.push(proyecto);
}

// Guardar los proyectos precargados en localStorage
localStorage.setItem("pixtovoxAssetProjects", JSON.stringify(proyectosNuevos));
console.log("Proyectos precargados en localStorage.");
} catch (error) {
console.error("Error al cargar proyectos:", error);
}
}
}

// Llamar a la función al iniciar la aplicación
cargarProyectosDesdeCarpeta();








/*
//texturas
// Inicializa la base de datos para la subapp niveles
function initTexturasDatabase() {
  if (!localStorage.getItem('pixtovoxTexturasProjects')) {
    localStorage.setItem('pixtovoxTexturasProjects', JSON.stringify([])); // Crea una lista vacía
  }
}

var texturas=[];

// Obtener todos los proyectos de niveles
function getAllTexturas() {
  return new Promise((resolve) => {
    texturas = JSON.parse(localStorage.getItem('pixtovoxTexturasProjects'));
    resolve(texturas);
    
   // console.log(texturas);
  });
  
  
}

let currentTexture=null;

function loadTextureList() {
  let panelTexturas = document.getElementById("panelTexturas");
  
  // Crear el botón de cerrar UNA VEZ
  const closeButton = document.createElement('button');
  closeButton.textContent = '❌';
  
  closeButton.style.right='1%';
  closeButton.style.fontSize='30px';
  
  closeButton.style.margin='10px';
  closeButton.onclick=()=>{
    
    panelTexturas.style.display="none";
  }
  // Crear un contenedor interno para las texturas.
  // Este div contendrá los botones de las texturas y
  // se le puede aplicar un padding para generar el espacio deseado.
  let textureContainer = document.createElement('div');
  textureContainer.classList.add('texture-container');
  
  // Limpiar el contenido del panel y agregar el botón de cerrar y el contenedor
  panelTexturas.innerHTML = '';
  panelTexturas.appendChild(closeButton);
  panelTexturas.appendChild(textureContainer);
  
  // Reiniciar scroll del panel
  panelTexturas.scrollLeft = 0;
  panelTexturas.scrollTop = 0;
  
  getAllTexturas()
    .then((texturas) => {
      // Limpiar el contenedor interno en caso de que ya tuviera contenido
      textureContainer.innerHTML = '';
      textureContainer.style.overflow='scroll';
      textureContainer.style.padding="1%";
      texturas.forEach((textura) => {
        // Crear el botón principal de textura
        let button = document.createElement('button');
        button.classList.add('texturaBtn');
        button.style.margin="10px";
        
        button.style.borderRadius="10px";
        
        
        
        if (textura.gifDataUrl) {
          button.style.backgroundImage = `url(${textura.gifDataUrl})`;
          button.style.backgroundSize = 'cover';
          button.style.backgroundPosition = 'center';
          button.id = textura.id;
        }
        
        button.onclick = () => {
          currentTexture = { id: textura.id, textura: textura.gifDataUrl };
          
           let imgTexturaBtn = document.getElementById('imgTexturaBtn');
 imgTexturaBtn.src = currentTexture.textura;
          // console.log(currentTexture);
        }
        
        // Agregar el botón al contenedor interno
        textureContainer.appendChild(button);
      });
    });
}

initTexturasDatabase();
loadTextureList();


// Lista de archivos JSON en la carpeta /demos
let rutaTexturas = [
  
"../demo/amanita.json"
];

// Función para cargar proyectos desde los archivos JSON
async function cargarTexturasDesdeCarpeta() {
const proyectos = JSON.parse(localStorage.getItem("pixtovoxTexturasProjects")) || [];
if (proyectos.length === 0) {
try {
const proyectosNuevos = [];

for (let ruta of rutaTexturas) {
const response = await fetch(`/apps/Texturas/demo/${ruta}`);
if (!response.ok) {
console.error(`Error al cargar ${ruta}: ${response.status} ${response.statusText}`);
continue; // Saltar este archivo si hay un error
}

let proyecto = await response.json();
proyectosNuevos.push(proyecto);
}

// Guardar los proyectos precargados en localStorage
localStorage.setItem("pixtovoxTexturasProjects", JSON.stringify(proyectosNuevos));
console.log("Proyectos precargados en localStorage.");
} catch (error) {
console.error("Error al cargar proyectos:", error);
}
}
}

// Llamar a la función al iniciar la aplicación
cargarTexturasDesdeCarpeta();
*/