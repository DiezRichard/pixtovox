//==================================
//===== Pantalla de Proyectos ======
//==================================

const projectScreen = document.getElementById('projectScreen');
const projectList = document.getElementById('projectList');
let buttonControls = document.querySelector('.button-controls');
const newProjectButton = document.createElement("button");

newProjectButton.id = "newProjectButton";
newProjectButton.style.minWidth="30%";
newProjectButton.style.minHeight="30%";
newProjectButton.style.background = "rgba(30, 30, 30, 0.1)";
 
newProjectButton.classList.add('tornasol-border');
//newProjectButton.classList.add('tornasol-text');

//newProjectButton.textContent = " +Nuevo";
newProjectButton.innerHTML = `
<span style="font-size: 24px;">+</span>
<span>Nuevo</span>
`;
newProjectButton.style.display = 'flex';
newProjectButton.style.flexDirection = 'column';
newProjectButton.style.alignItems = 'center';
newProjectButton.style.padding = '10px';

newProjectButton.classList.add('hover-element');
newProjectButton.dataset.description="Crea un nuevo proyecto. Recuerda guardar periódicamente para no perder tu progreso";

const importProject = document.getElementById('importProject');
const importFile = document.getElementById('importFile');


// ====================
// Animación del Div
// ====================
function fadeInProjectScreen() {
//activarTouchMove(); 
//desactivarTouchMove(); 
projectScreen.style.display = 'flex';
projectScreen.classList.remove('fade-out');
void projectScreen.offsetWidth;
projectScreen.classList.add('fade-in');
}

window.matchMedia('(orientation: landscape)').addEventListener('change', (e) => {
if (e.matches) {
projectList.style.height = '100vh';
projectList.style.alignItems = 'center';
} else {
projectList.style.height = '';
projectList.style.alignItems = '';
}
});

//===========================
//=== Cargar Lista Proyectos ===
//===========================//
function loadProjectList() {

// Crear espaciador
const spacer = document.createElement('div');
spacer.classList.add('spacer3');
spacer.id="spacer";
spacer.style.minWidth = '15vw';
spacer.style.minHeight = '5vw';
spacer.style.maxHeight = '5vw';
spacer.style.flexShrink = '0';
spacer.style.order = '-990';
//spacer.style.backgroundColor="yellow";



// Crear espaciador
const spacer2 = document.createElement('div');
spacer2.id = "spacer2";
spacer2.classList.add('spacer2');
spacer2.style.minWidth = '30vw';
spacer2.style.minHeight = '30vw';
spacer2.style.flexShrink = '0';

getAllProjects()
.then((projects) => {
projectList.innerHTML = ''; // Limpiar lista existente

projectList.scrollLeft=0;
projectList.scrollTop=0;

projectList.appendChild(spacer);


projectList.appendChild(importProject);

projectList.appendChild(importFile);

projectList.appendChild(newProjectButton);




// Crear proyectos
projects.forEach((project) => {
// Crear contenedor del proyecto
const container = document.createElement('div'); // Contenedor para el proyecto y el botón
container.classList.add('project-container');

// Crear el botón principal
const button = document.createElement('button');
button.classList.add('project-button');
button.classList.add('tornasol-border');
button.onclick = () => openProject(project.id); // Abrir proyecto

// Usar el dataURL como fondo del botón si existe
if (project.gifDataUrl) {
button.style.backgroundImage = `url(${project.gifDataUrl})`;
button.style.backgroundSize = 'cover';
button.style.backgroundPosition = 'center';
} else {
console.error(`El proyecto "${project.id}" no tiene un dataURL válido para el GIF.`);
}

// Crear el botón de eliminar
const deleteButton = document.createElement('button');
deleteButton.textContent = '❌'; // Icono para el botón eliminar
deleteButton.classList.add('delete-project-button');

/*
// Acción para eliminar el proyecto
deleteButton.onclick = (event) => {
event.stopPropagation(); // Evita que se active el evento del botón principal
if (confirm(`¿Estás seguro de que deseas eliminar el proyecto "${project.id}"?`)) {
deleteProject(project.id)
.then(() => {
mostrarMensaje(`Proyecto "${project.id}" eliminado.`, 'outputMaincontent');
loadProjectList(); // Recargar la lista después de eliminar
})
.catch((error) => console.error('Error al eliminar el proyecto:', error));
}
};
*/

// Variable para almacenar el id del proyecto seleccionado
//let selectedProjectId = project.id;

// Al hacer clic en el botón de eliminar, se muestra el modal personalizado
deleteButton.onclick = (event) => {
event.stopPropagation(); // Evita que se active el evento del botón principal
// Almacena el id del proyecto seleccionado
selectedProjectId = project.id;
// Asigna el id en el span del modal para mostrarlo
document.getElementById('modalProjectId').innerText = selectedProjectId;
// Muestra el modal
document.getElementById('confirmDeleteModal').style.display = 'flex';
};

// Evento para confirmar la eliminación
document.getElementById('confirmDeleteBtn').onclick = () => {
if (selectedProjectId) {
deleteProject(selectedProjectId)
.then(() => {
mostrarMensaje(`Proyecto "${selectedProjectId}" eliminado.`, 'outputMaincontent');
loadProjectList(); // Recargar la lista después de eliminar
})
.catch((error) => console.error('Error al eliminar el proyecto:', error));
}
// Oculta el modal y resetea la variable
document.getElementById('confirmDeleteModal').style.display = 'none';
selectedProjectId = null;
};

// Evento para cancelar la eliminación
document.getElementById('cancelDeleteBtn').onclick = () => {
document.getElementById('confirmDeleteModal').style.display = 'none';
selectedProjectId = null;
};

// También se puede cerrar el modal haciendo clic en la "X"
document.getElementById('closeModal').onclick = () => {
document.getElementById('confirmDeleteModal').style.display = 'none';
selectedProjectId = null;
};

// Ensamblar elementos
button.appendChild(deleteButton); // Añadir el botón eliminar al botón principal
container.appendChild(button); // Añadir el botón principal al contenedor
projectList.appendChild(container); // Añadir el contenedor a la lista de proyectos
});


//spacer2.style.backgroundColor="green";
projectList.appendChild(spacer2);

window.matchMedia('(orientation: landscape)').addEventListener('change', (e) => {

spacer.style.minWidth = '5vw';
spacer.style.minHeight = '5vw';



spacer2.style.minWidth = '15vw';
spacer2.style.height = '15vh';
spacer2.style.display="none;"

});

window.matchMedia('(orientation: portrait)').addEventListener('change', (e) => {

//spacer.style.display="flex;"
spacer.style.minHeight = '5vw';
spacer.style.maxHeight = '5vw';

});


})
.catch((error) => console.error('Error al cargar proyectos:', error));

}// FIN CARGAR LISTA 



// ====================
// Cargar Proyecto en MainContent
// ====================
function loadProjectInMainContent(project) {


sprites = project.sprites || [];
gridSize = project.gridSize || 9;

switch (project.gridSize) {
case 9:
viewSize = 9;
break;
default:
viewSize = 15;
break;
}


if (buttonControls) {
buttonControls.scrollLeft = 0;
}

updateCurrentSprite();
updateSpriteBar();
updateLayerBar();
layerBar.style.display = "flex";


currentSpriteIndex = 0;
currentLayerIndex = 0;
isPreviewMode = false;
is3DActive = false;
isPlaying = false;

setActiveList("layer");
updateCurrentLayer();


//toggleCapas();
}

// ====================
// Abrir Proyecto
// ====================

function openProject(projectId) {
getProjectById(projectId)
.then((project) => {
if (project) {
// Inicia la transición entre pantallas
projectScreen.classList.add('fade-out');

mainContent.classList.remove('fade-out');
setTimeout(() => {
projectScreen.style.display = 'none'; // Oculta projectScreen
const mainContent = document.getElementById('mainContent');
mainContent.style.display = 'flex'; // Muestra mainContent
mainContent.classList.add('fade-in'); // Transición de entrada

if (buttonControls) {
buttonControls.scrollLeft = 0;
}



const outputMaincontent = document.getElementById('outputMaincontent');

// Carga los datos del proyecto al mainContent
currentProjectID = project.id;

loadProjectInMainContent(project);
window.parent.postMessage('hideMenu', '*'); // Enviar mensaje para ocultar el menú
}, 1000); // Tiempo de la animación de fade-out
} else {
mostrarMensaje('No se encontró el proyecto.','outputMaincontent');
}
})
.catch((error) => console.error('Error al abrir el proyecto:', error));


}

// ============================
// === Guardar Proyecto ===
// ============================
function blobToBase64(blob) {
return new Promise((resolve, reject) => {
const reader = new FileReader();
reader.onloadend = () => resolve(reader.result);
reader.onerror = reject;
reader.readAsDataURL(blob); // Convierte el Blob a base64
});
}


/*
function saveProjectHandler() {
// Desactiva la interacción del usuario
disableUserInteraction();

// Actualiza el sprite actual (guarda la capa activa en el sprite)
saveCurrentLayer();
//saveCurrentSprite();

// Verifica si el ID del proyecto ya existe, si no, asigna uno nuevo
if (!currentProjectID) {
currentProjectID = Date.now().toString();
}

// Genera el thumbnail (GIF) usando la estructura actualizada de sprites
generateThumbnail(sprites).then((thumbnailBlob) => {
if (!thumbnailBlob || !(thumbnailBlob instanceof Blob)) {
console.error('El Blob del GIF no es válido:', thumbnailBlob);
mostrarMensaje('Error al generar el GIF. No se guardará el proyecto.', 'outputMaincontent');
enableUserInteraction();
return;
}
// Convierte el Blob a base64 antes de guardar
blobToBase64(thumbnailBlob).then((dataUrl) => {
// Crea el objeto proyecto usando la nueva estructura de sprites
const project = {
id: currentProjectID,
sprites: sprites, // Cada sprite incluye: gridSize, currentLayerIndex, layers (con sus cells)
gridSize: gridSize,
gifDataUrl: dataUrl // Guarda el GIF como base64
};

saveProject(project)
.then(() => {
mostrarMensaje('Proyecto guardado exitosamente.', 'outputMaincontent');

setTimeout(() => {
enableUserInteraction(); // Reactivar interacción del usuario
}, 1000); // Ajusta el tiempo según sea necesario

})
.catch((error) => {
console.error('Error al guardar el proyecto:', error);
setTimeout(() => {
enableUserInteraction(); // Reactivar interacción del usuario
}, 1000); // Ajusta el tiempo según sea necesario

});
});
});
}
*/

function saveProjectHandler() 
{

disableUserInteraction();
// Muestra el cuadro de guardar proyecto
const cuadroGuardarProyecto = document.getElementById('cuadroGuardarProyecto');
cuadroGuardarProyecto.style.display = 'flex'; // Muestra el div
cuadroGuardarProyecto.style.zIndex = '9999';

// Agregar eventos a los botones
document.getElementById('cerrarCuadro').onclick = () => {
cuadroGuardarProyecto.style.display = 'none'; // Oculta el div
enableUserInteraction(); // Reactiva la interacción del usuario
};


document.getElementById('reemplazarBtn').onclick = () => {

cuadroGuardarProyecto.style.display = 'none'; //

// Desactiva la interacción del usuario
disableUserInteraction();
guardarProyecto(true);
};

document.getElementById('nuevoBtn').onclick = () => {

cuadroGuardarProyecto.style.display = 'none'; 


disableUserInteraction();
guardarProyecto(false); 
};
}

function guardarProyecto(reemplazar) {


if (!reemplazar) {
currentProjectID = Date.now().toString(); // Nuevo ID
}


generateThumbnail(sprites).then((thumbnailBlob) => {
if (!thumbnailBlob || !(thumbnailBlob instanceof Blob)) {
console.error('El Blob del GIF no es válido:', thumbnailBlob);
mostrarMensaje('Error al generar el GIF. No se guardará el proyecto.', 'outputMaincontent');
enableUserInteraction();
cuadroGuardarProyecto.style.display = 'none'; // Oculta el div
return;
}
// Convierte el Blob a base64 antes de guardar
blobToBase64(thumbnailBlob).then((dataUrl) => {
// Crea el objeto proyecto usando la nueva estructura de sprites
const project = {
id: currentProjectID,
sprites: sprites, // Cada sprite incluye: gridSize, currentLayerIndex, layers (con sus cells)
gridSize: gridSize,
gifDataUrl: dataUrl // Guarda el GIF como base64
};

saveProject(project)
.then(() => {
mostrarMensaje('Proyecto guardado exitosamente.', 'outputMaincontent');
cuadroGuardarProyecto.style.display = 'none'; // Oculta el div
})
.catch((error) => {
console.error('Error al guardar el proyecto:', error);
cuadroGuardarProyecto.style.display = 'none'; // Oculta el div
})
.finally(() => {
enableUserInteraction(); // Reactivar interacción del usuario
});
});
});
}


function disableUserInteraction() {
const overlay = document.getElementById('disableuserinteraction');
overlay.style.display = 'block'; // Muestra el overlay
}

function enableUserInteraction() {
const overlay = document.getElementById('disableuserinteraction');
overlay.style.display = 'none'; // Oculta el overlay
}



// Asigna el evento click al botón
document.getElementById('saveProject').addEventListener('click', saveProjectHandler);

// ====================
// Evento Nuevo Proyecto
// ====================

newProjectButton.addEventListener('click', () => {
const projectScreen = document.getElementById('projectScreen');
const gridSizeScreen = document.getElementById('gridSizeScreen'); // Asegúrate de que existe en el HTML

// Inicia fade-out del Project Screen
projectScreen.classList.add('fade-out');

// Espera que termine el fade-out antes de iniciar el fade-in
setTimeout(() => {
projectScreen.style.display = 'none';
gridSizeScreen.style.display = 'flex'; // Muestra el Initial Screen

sprites=[];
sprites3d=[];
gridSize=9;

fadeInGridSizeScreen(); // Llama a la función del fade-in
// Cuando cambie el estado, envías un mensaje al documento principal
//window.parent.postMessage('ocultarBoton', '*'); // '*' puede ser reemplazado por el origen específico
}, 1000); // Tiempo de la animación de fade-out
// Cuando cambie el estado, envías un mensaje al documento principal
//window.parent.postMessage('ocultarBoton', '*'); // '*' puede ser reemplazado por el origen específico

});





//===============================
//======= VOLVER A LISTA DE PROYECTOS =======
//===============================
/*
function returnToProjectList() {

document.addEventListener("DOMContentLoaded", () => {
const buttonControls = document.querySelector(".button-controls");
if (buttonControls) {
buttonControls.scrollTop = 0; // Reinicia el scroll vertical
// Si también hay scroll horizontal, puedes usar:
buttonControls.scrollLeft = 0;
}
});

// Pregunta de confirmación si hay cambios sin guardar
const userConfirmed = confirm("¿Deseas salir sin guardar los cambios?");

if (!userConfirmed) {
return; // Si el usuario cancela, salir de la función
}

const mainContent = document.getElementById("mainContent");
const projectScreen = document.getElementById("projectScreen");


// Iniciar animación de salida de mainContent
mainContent.classList.add("fade-out");


setTimeout(() => {
mainContent.style.display = "none"; // Ocultar pantalla principal
projectScreen.style.display = "flex"; // Mostrar lista de proyectos
projectScreen.classList.remove("fade-out");
mainContent.classList.remove('fade-out');
projectScreen.classList.add("fade-in");

// Resetear variables
sprites3d = [];
camera.rotation = { x: 0, y: 0, z: 0 };
currentLayerIndex = 0;
currentSpriteIndex = 0;
currentSprite = "";
currentLayer = "";
updateSpriteBar();
updateLayerBar();
sprites = null;
copiedSprite = null;
currentProjectID = null;
copiedLayer = null;

activeList = "";
layerBar.innerHTML = "";
spriteBar.innerHTML = "";
isPreviewMode = false;
is3DActive = false;
isPlaying = false;
clearInterval(animationInterval);
playPauseButton.textContent = "▶️";

loadProjectList(); // Recargar la lista de proyectos
 window.parent.postMessage('showMenu', '*'); // Enviar mensaje para mostrar el menú
 
}, 1000); // Duración de la animación


}

document.getElementById("exit").addEventListener("click", returnToProjectList);
*/

// Función que inicia el regreso a la lista de proyectos
function doReturnToProjectList() {
projectList.scrollTop = 0;
projectList.scrollLeft = 0;

const mainContent = document.getElementById("mainContent");
const projectScreen = document.getElementById("projectScreen");

// Iniciar animación de salida de mainContent
mainContent.classList.add("fade-out");

setTimeout(() => {
mainContent.style.display = "none"; // Ocultar pantalla principal
projectScreen.style.display = "flex"; // Mostrar lista de proyectos
projectScreen.classList.remove("fade-out");
mainContent.classList.remove("fade-out");
projectScreen.classList.add("fade-in");

// Resetear variables
sprites3d = [];
camera.rotation = { x: 0, y: 0, z: 0 };
currentLayerIndex = 0;
currentSpriteIndex = 0;
currentSprite = "";
currentLayer = "";
updateSpriteBar();
updateLayerBar();
sprites = null;
copiedSprite = null;
currentProjectID = null;
copiedLayer = null;

activeList = "";
layerBar.innerHTML = "";
spriteBar.innerHTML = "";
isPreviewMode = false;
is3DActive = false;
isPlaying = false;
clearInterval(animationInterval);
playPauseButton.textContent = "▶️";

loadProjectList(); // Recargar la lista de proyectos
window.parent.postMessage('showMenu', '*'); // Enviar mensaje para mostrar el menú
}, 1000); // Duración de la animación
}

// Función para abrir el modal de salida
function openSalirModal() {
document.getElementById("cuadroSalir").style.display = "flex";
}

// Función principal que se activa al pulsar el botón de "exit"
function returnToProjectList() {
// Reiniciar el scroll vertical (y horizontal si es necesario)
const buttonControls = document.querySelector(".button-controls");
if (buttonControls) {
buttonControls.scrollTop = 0;
buttonControls.scrollLeft = 0;
}

// En lugar de usar confirm, se abre el modal personalizado
openSalirModal();
}

// Asignar evento al botón "exit"
document.getElementById("exit").addEventListener("click", returnToProjectList);

// Eventos para los botones y la "X" del modal de salida
document.getElementById("confirmarSalirBtn").onclick = function() {
document.getElementById("cuadroSalir").style.display = "none";
doReturnToProjectList();
};

document.getElementById("cancelarSalirBtn").onclick = function() {
document.getElementById("cuadroSalir").style.display = "none";
};

document.getElementById("cerrarCuadroSalir").onclick = function() {
document.getElementById("cuadroSalir").style.display = "none";
};

// Inicializar base de datos y cargar lista de proyectos al inicio
initDatabase();
loadProjectList();







